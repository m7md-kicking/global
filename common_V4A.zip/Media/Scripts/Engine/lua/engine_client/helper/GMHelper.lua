local ModuleBlockConfig = T(Global, "ModuleBlockConfig")
local Settings = {}
local KeyBoardI = {}

local sendMessage = ShellInterface.sendMessage
ShellInterface.sendMessage = function(self, messageType, msgData)
    msgData.senderUserId = tostring(Game:getPlatformUserId()) 
    sendMessage(self, messageType, json.encode(msgData))
end

---@private
function KeyBoardI:init()
    if Platform.isWindow() and CGame.requireKeyboardEvent then
        CGame.Instance():requireKeyboardEvent()
        CEvents.KeyUpEvent:registerCallBack(self.onKeyUp)
        CEvents.KeyUpEvent:registerCallBack(self.onEventHold)
    end
end

function KeyBoardI:OnUpdate() 
        local player = PlayerManager:getClientPlayer()
        if player == nil then
            return
        end
        local pos = player.Player:getPosition()
        MsgSender.sendTopTips(1, string.format("XYZ: %s / %s / %s", tostring(math.floor(pos.x)), tostring(math.floor(pos.y)), tostring(math.floor(pos.z))))
    end
    
function KeyBoardI.onKeyUp(keyName, keyCode)
    A = not A
    if keyName == "F" then
    GUIGMControlPanel:show()
	UIHelper.showToast("^FF00EEPanel Open")
	if A then
    GUIGMControlPanel:hide()
	UIHelper.showToast("^FF00EEPanel Closed")
end
	return
end

    if keyName == "R" then
	Server:respawn()
end

    if keyName == "M" then
	RootGuiLayout.Instance():showMainControl()
    local moveDir = VectorUtil.newVector3(0.0, 1.35, 0.0)
    local player = PlayerManager:getClientPlayer()
    player.Player:setAllowFlying(true)
    player.Player:setFlying(true)
    player.Player:moveEntity(moveDir)
	return
end
    local idx = tonumber(keyName)
    return true
end

KeyBoardI:init()
function Game:init()
local player = PlayerManager:getClientPlayer()
MsgSender.sendOtherTips(99999999, "^FFCC00[Admin Panel v4a] ^CC0000by APanel Team")
MsgSender.sendCenterTips(6, "^00B300Welcome!")
local pos = player.Player:getPosition()
MsgSender.sendBottomTips(99999999, string.format("XYZ: %s / %s / %s", tostring(math.floor(pos.x)), tostring(math.floor(pos.y)), tostring(math.floor(pos.z))))
MsgSender.sendMsg("^FF00EE[AP]: Initialization")
    LuaTimer:schedule(function()
     MsgSender.sendMsg("^FB00FF[AP]: Success, for any questions/suggestions write to Discord: iikj. GM modder:TAreLKA089|")
    end, 4000)
    LuaTimer:schedule(function()
     MsgSender.sendMsg("^FB00FF[AP]: Version: 1.9.1")
    end, 4005)
	LuaTimer:schedule(function()
     MsgSender.sendMsg("^FB00FF[Tips]: Press R To Respawn And M To Fly")
    end, 4500)
  ClientHelper.putBoolPrefs("EnableDoubleJumps", true)
      ClientHelper.putBoolPrefs("banClickCD", false)
	  ClientHelper.putFloatPrefs("RenderTextAlpha", 4)
ClientHelper.putBoolPrefs("IsShowItemDurability", true)
ClientHelper.putBoolPrefs("setSwordBreakBlock", true)
ClientHelper.putBoolPrefs("IsCreatureBloodBar", true)
ClientHelper.putBoolPrefs("IsCreatureCollision", false)
ClientHelper.putIntPrefs("HurtProtectTime", 0)
ClientHelper.putBoolPrefs("IsShowCrafting", true)
ClientHelper.putBoolPrefs("BlockCustomMeta", true)
ClientHelper.putBoolPrefs("IsCanSprint", true)
UIHelper.newEngineGUILayout("GUIGMMain", "GMMain.json")
    self.CGame = CGame.Instance()
	self.doubleJumpCount = 100000
    self.GameType = CGame.Instance():getGameType()
    self.EnableIndie = CGame.Instance():isEnableIndie(true)
    self.Blockman = Blockman.Instance()
    self.World = Blockman.Instance():getWorld()
    self.LowerDevice = CGame.Instance():isLowerDevice()
    EngineWorld:setWorld(self.World)
end

function Game:isOpenGM()
    return isClient or TableUtil.include(AdminIds, tostring(Game:getPlatformUserId()))
end

local Settings = {}
GMSetting = {}

local function isGMOpen(userId)
    if isClient then
        return true
    end
    return TableUtil.include(AdminIds, tostring(userId))
end

function GMSetting:addTab(tab_name, index)
    for _, setting in pairs(Settings) do
        if setting.name == tab_name then
            setting.items = {}
            return
        end
    end
    index = index or #Settings + 1
    table.insert(Settings, index, { name = tab_name, items = {} })
end

function GMSetting:addItem(tab_name, item_name, func_name, ...)
    local settings
    for _, group in pairs(Settings) do
        if group.name == tab_name then
            settings = group
        end
    end
    if not settings then
        GMSetting:addTab(tab_name)
        GMSetting:addItem(tab_name, item_name, func_name, ...)
        return
    end
    table.insert(settings.items, { name = item_name, func = func_name, params = { ... } })
end

function GMSetting:getSettings()
    return Settings
end

GMSetting:addTab("常用")
GMSetting:addItem("常用", "开启飞行", "setAllowFlying")
GMSetting:addItem("常用", "ACE", "InTheAirCheat")
GMSetting:addItem("常用", "Teest", "changePlayerSpeed", 1000)
GMSetting:addItem("常用", "尝试开始游戏", "tryStartGame")
GMSetting:addItem("常用", "找活着的玩家", "findLifePlayer")
GMSetting:addItem("常用", "清数据退游戏", "clearDBAndLogout")
GMSetting:addItem("常用", "重置首充", "resetSumRecharge")
GMSetting:addItem("常用", "清除背包", "clearInventory")
GMSetting:addItem("常用", "region", "showUserRegion")
GMSetting:addItem("常用", "", "")
GMSetting:addItem("常用", "ErrorLog权限(全局)", "addErrorPlayer", true)
GMSetting:addItem("常用", "ErrorLog权限(最近)", "addErrorPlayer", false)
GMSetting:addItem("常用", "", "")
GMSetting:addItem("常用", "查询BoolKey", "queryBoolKey")
GMSetting:addItem("常用", "查询StringKey", "queryStringKey")
GMSetting:addItem("常用", "", "")
GMSetting:addItem("常用", "开启Debug", "openDebug")
GMSetting:addItem("常用", "关闭Debug", "closeDebug")
GMSetting:addItem("常用", "打开Common包Log", "openCommonPacketDebug")
GMSetting:addItem("常用", "关闭Common包Log", "closeCommonPacketDebug")
GMSetting:addItem("常用", "", "")
GMSetting:addItem("常用", "Debug左移(←)", "moveDebugInfo", -5, 0)
GMSetting:addItem("常用", "Debug右移(→)", "moveDebugInfo", 5, 0)
GMSetting:addItem("常用", "Debug上移(↑)", "moveDebugInfo", 0, -5)
GMSetting:addItem("常用", "Debug下移(↓)", "moveDebugInfo", 0, 5)
GMSetting:addItem("常用", "", "")
GMSetting:addItem("常用", "修改时分(6000)", "setWorldTime", 6000)
GMSetting:addItem("常用", "修改时分(12000)", "setWorldTime", 12000)
GMSetting:addItem("常用", "修改时分(18000)", "setWorldTime", 18000)
GMSetting:addItem("常用", "修改时分(24000)", "setWorldTime", 24000)
GMSetting:addItem("常用", "", "")
GMSetting:addItem("常用", "开启录屏模式", "openScreenRecord")
GMSetting:addItem("常用", "GM按钮透明", "makeGmButtonTran")
GMSetting:addItem("常用", "Lua热更新(开)", "changeLuaHotUpdate", true)
GMSetting:addItem("常用", "Lua热更新(关)", "changeLuaHotUpdate", false)
GMSetting:addItem("常用", "", "")
GMSetting:addItem("常用", "开启(埋点弹窗)", "changeOpenEventDialog", true)
GMSetting:addItem("常用", "关闭(埋点弹窗)", "changeOpenEventDialog", false)
GMSetting:addItem("常用", "打印UI(关)", "setOutputUIName")
GMSetting:addItem("常用", "关闭全局文本", "setGlobalShowText")
GMSetting:addItem("常用", "", "")
GMSetting:addItem("常用", "Telnet(客户端)", "telnetClient")
GMSetting:addItem("常用", "Telnet(服务器)", "telnetServer")
GMSetting:addItem("常用", "拷贝client.log", "copyClientLog")

GMSetting:addTab("危险")
GMSetting:addItem("危险", "DisableOpenGLAPI", "DisableGraphicAPI")
GMSetting:addItem("危险", "D CPUTimer test", "DisableGraphicAPIAndTestCPU")
GMSetting:addItem("危险", "D GPUTimer test", "DisableGraphicAPIAndTestGPU")
GMSetting:addItem("危险", "D DrawCall test", "DisableGraphicAPIAndDrawCallTest")
GMSetting:addItem("危险", "", "")
GMSetting:addItem("危险", "关闭服务器", "closeServer")
GMSetting:addItem("危险", "GM权限(全局)", "addGMPlayer", true)
GMSetting:addItem("危险", "GM权限(最近)", "addGMPlayer", false)
GMSetting:addItem("危险", "测试非法特效文件", "testinValidEffect", false)
GMSetting:addItem("危险", "", "")
GMSetting:addItem("危险", "CPUTimer On", "setCPUTimerEnabled", true)
GMSetting:addItem("危险", "CPUTimer Off", "setCPUTimerEnabled", false)
GMSetting:addItem("危险", "GPUTimer On", "setGPUTimerEnabled", true)
GMSetting:addItem("危险", "GPUTimer Off", "setGPUTimerEnabled", false)
GMSetting:addItem("危险", "DrawCallTest On", "SetEnabledRenderFrameTimer", true)
GMSetting:addItem("危险", "打印性能测试结果", "printCPUTimerResult")
GMSetting:addItem("危险", "自动性能测试", "autoPrintResults")
GMSetting:addItem("危险", "自动开关测试", "autoProfilePerformance")
GMSetting:addItem("危险", "update shader", "updateAllShaders")
GMSetting:addItem("危险", "auto update shader", "setNeedMonitorShader")
GMSetting:addItem("危险", "DrawCallDisabled", "setDrawCallDisabled")
GMSetting:addItem("危险", "MinimumGeometry", "setMinimumGeometry")
GMSetting:addItem("危险", "ColorBlendDisabled", "setColorBlendDisabled")
GMSetting:addItem("危险", "ZTestDisabled", "setZTestDisabled")
GMSetting:addItem("危险", "ZWriteDisabled", "setZWriteDisabled")
GMSetting:addItem("危险", "UseSmallTexture", "setUseSmallTexture")
GMSetting:addItem("危险", "UseSmallViewport", "setUseSmallViewport")
GMSetting:addItem("危险", "UseSmallVBO", "setUseSmallVBO")
GMSetting:addItem("危险", "ClearColorDisabled", "setClearColorDisabled")
GMSetting:addItem("危险", "", "")
GMSetting:addItem("危险", "(开)主窗口UI独立渲染", "setRenderMainScreenSeparate", true)
GMSetting:addItem("危险", "(关)主窗口UI独立渲染", "setRenderMainScreenSeparate", false)
GMSetting:addItem("危险", "(开)方块合批渲染", "setEnableMergeBlock", true)
GMSetting:addItem("危险", "(关)方块合批渲染", "setEnableMergeBlock", false)
GMSetting:addItem("危险", "AnvilToObj", "AnvilToObj")

GMSetting:addTab("枪火配置")
GMSetting:addItem("枪火配置", "枪火配置(开)", "setShowGunFlameCoordinate", true)
GMSetting:addItem("枪火配置", "枪火配置(关)", "setShowGunFlameCoordinate", false)

GMSetting:addTab("枪火配置(1)")
GMSetting:addItem("枪火配置(1)", "复制第一人称", "copyShowGunFlameParam", 1)
GMSetting:addItem("枪火配置(1)", "", "")
GMSetting:addItem("枪火配置(1)", "第一人称(x)+0.1", "changeGunFlameParam", "GunFlameFrontOff1", 0.1)
GMSetting:addItem("枪火配置(1)", "第一人称(x)+0.01", "changeGunFlameParam", "GunFlameFrontOff1", 0.01)
GMSetting:addItem("枪火配置(1)", "第一人称(x)-0.1", "changeGunFlameParam", "GunFlameFrontOff1", -0.1)
GMSetting:addItem("枪火配置(1)", "第一人称(x)-0.01", "changeGunFlameParam", "GunFlameFrontOff1", -0.01)
GMSetting:addItem("枪火配置(1)", "", "")
GMSetting:addItem("枪火配置(1)", "第一人称(y)+0.1", "changeGunFlameParam", "GunFlameRightOff1", 0.1)
GMSetting:addItem("枪火配置(1)", "第一人称(y)+0.01", "changeGunFlameParam", "GunFlameRightOff1", 0.01)
GMSetting:addItem("枪火配置(1)", "第一人称(y)-0.1", "changeGunFlameParam", "GunFlameRightOff1", -0.1)
GMSetting:addItem("枪火配置(1)", "第一人称(y)-0.01", "changeGunFlameParam", "GunFlameRightOff1", -0.01)
GMSetting:addItem("枪火配置(1)", "", "")
GMSetting:addItem("枪火配置(1)", "第一人称(z)+0.1", "changeGunFlameParam", "GunFlameDownOff1", 0.1)
GMSetting:addItem("枪火配置(1)", "第一人称(z)+0.01", "changeGunFlameParam", "GunFlameDownOff1", 0.01)
GMSetting:addItem("枪火配置(1)", "第一人称(z)-0.1", "changeGunFlameParam", "GunFlameDownOff1", -0.1)
GMSetting:addItem("枪火配置(1)", "第一人称(z)-0.01", "changeGunFlameParam", "GunFlameDownOff1", -0.01)
GMSetting:addItem("枪火配置(1)", "", "")
GMSetting:addItem("枪火配置(1)", "第一人称(s)+0.1", "changeGunFlameParam", "GunFlameScale1", 0.1)
GMSetting:addItem("枪火配置(1)", "第一人称(s)+0.01", "changeGunFlameParam", "GunFlameScale1", 0.01)
GMSetting:addItem("枪火配置(1)", "第一人称(s)-0.1", "changeGunFlameParam", "GunFlameScale1", -0.1)
GMSetting:addItem("枪火配置(1)", "第一人称(s)-0.01", "changeGunFlameParam", "GunFlameScale1", -0.01)
--Main
GMSetting:addTab("^FFFF00Movement")
GMSetting:addItem("^FFFF00Movement", "^00FFDDHead Text", "HeadText")
GMSetting:addItem("^FFFF00Movement", "^00FFDDY+", "inTheAirCheat")
GMSetting:addItem("^FFFF00Movement", "^00FFDDY+(Set)", "AdvancedUp")
GMSetting:addItem("^FFFF00Movement", "^00FFDDX+(Set)", "AdvancedIn")
GMSetting:addItem("^FFFF00Movement", "^00FFDDZ+(Set)", "AdvancedOn")
GMSetting:addItem("^FFFF00Movement", "^00FFDDXYZ(Set)", "AdvancedDirect")
GMSetting:addItem("^FFFF00Movement", "^00FFDDX+", "GoTO10Blocks")
GMSetting:addItem("^FFFF00Movement", "^00FFDDX-", "GoTO10BlocksDown")
GMSetting:addItem("^FFFF00Movement", "^00FFDDFly", "MyLoveFly")
GMSetting:addItem("^FFFF00Movement", "^00FFDDFog", "Fog")
GMSetting:addItem("^FFFF00Movement", "^00FFDDWWE_Camera", "WWE_Camera")
GMSetting:addItem("^FFFF00Movement", "^00FFDDNoclip", "Noclip")
GMSetting:addItem("^FFFF00Movement", "^00FFDDDevFly", "DevFlyI")
GMSetting:addItem("^FFFF00Movement", "^00FFDDLongJump", "LongJump")
GMSetting:addItem("^FFFF00Movement", "^00FFDDWaterPush", "WaterPush")
GMSetting:addItem("^FFFF00Movement", "^00FFDDSharpFly", "SharpFly")
GMSetting:addItem("^FFFF00Movement", "^00FFDDSpeed", "SpeedManager")
GMSetting:addItem("^FFFF00Movement", "^00FFDDSpeedUp", "SpeedUp")
GMSetting:addItem("^FFFF00Movement", "^00FFDDSettingLongjump", "SettingLongjump")
GMSetting:addItem("^FFFF00Movement", "^00FFDDDevNoClip", "DevnoClip")
GMSetting:addItem("^FFFF00Movement", "^00FFDDStepHeight", "StepHeight")
GMSetting:addItem("^FFFF00Movement", "^00FFDDNoFall", "NoFall")
GMSetting:addItem("^FFFF00Movement", "^00FFDDJumpHeight", "JumpHeight")
GMSetting:addItem("^FFFF00Movement", "^00FFDDNoFall (Set)", "NoFallSet")
GMSetting:addTab("^FF0000Combat")
GMSetting:addItem("^FF0000Combat", "^00FFDDReach", "Reach")
GMSetting:addItem("^FF0000Combat", "^00FFDDBowSpeed", "BowSpeed", 1000)
GMSetting:addItem("^FF0000Combat", "^00FFDDAttackCD", "BanClickCD")
GMSetting:addItem("^FF0000Combat", "^00FFDDActtackReach (Set)", "ReachSet")
GMSetting:addItem("^FF0000Combat", "^00FFDDBlockReachDistance (Set)", "BlockReachSet")
GMSetting:addItem("^FF0000Combat", "^00FFDDArmSpeed", "ArmSpeed")
GMSetting:addTab("^CC9900Player")
GMSetting:addItem("^CC9900Player", "^00FFDDBoy", "changePlayerActor", 1)
GMSetting:addItem("^CC9900Player", "^00FFDDGirl", "changePlayerActor", 2)
GMSetting:addItem("^CC9900Player", "^00FFDDBreakSpeed", "FustBreakBlockMode")
GMSetting:addItem("^CC9900Player", "^00FFDDRespawn", "RespawnTool")
GMSetting:addItem("^CC9900Player", "^00FFDDTeleportByUID", "TeleportByUID")
GMSetting:addItem("^CC9900Player", "^00FFDD/tp", "tpPos")
GMSetting:addItem("^CC9900Player", "^00FFDDQuickPlaceBlock", "quickblock")
GMSetting:addItem("^CC9900Player", "^00FFDDChangeActorForMe", "ChangeActorForMe")
GMSetting:addItem("^CC9900Player", "^00FFDDParachute", "startParachute")
GMSetting:addItem("^CC9900Player", "^00FFDDFlyParachute", "FlyParachute")
GMSetting:addItem("^CC9900Player", "^00FFDDBlink", "BlinkOP")
GMSetting:addItem("^CC9900Player", "^00FFDDSpamRespawn", "SpamRespawn")
GMSetting:addItem("^CC9900Player", "^00FFDDChangeScale", "changeScale")
GMSetting:addItem("^CC9900Player", "^00FFDDInfinite Bridge", "infbrid1")
GMSetting:addTab("^33CC33Misc")
GMSetting:addItem("^33CC33Misc", "^00FFDDTreasureNoClip", "NoclipOP")
GMSetting:addItem("^33CC33Misc", "^00FFDDBlockmanCollision", "BlockmanCollision")
GMSetting:addItem("^33CC33Misc", "^00FFDDFreecam", "Freecam")
GMSetting:addItem("^33CC33Misc", "^00FFDDChangeNick", "ChangeNick")
GMSetting:addItem("^33CC33Misc", "^00FFDDShowAllCobtrol", "ShowAllCobtrolXD")
GMSetting:addItem("^33CC33Misc", "^00FFDDJailBreakBypass", "JailBreakBypass")
GMSetting:addItem("^33CC33Misc", "^00FFDDTreasureHunterNoClip", "NoclipOP")
GMSetting:addItem("^33CC33Misc", "^00FFDDBedWarsBypass", "BW")
GMSetting:addItem("^33CC33Misc", "^00FFDDBedWarsBypassV2", "BWV2")
GMSetting:addItem("^33CC33Misc", "^00FFDDTreasure Reset", "MineReset")
GMSetting:addTab("^FFFF99Visual")
GMSetting:addItem("^FFFF99Visual", "^00FFDDViewBobbing", "ViewBobbing")
GMSetting:addItem("^FFFF99Visual", "^00FFDDHideArm", "HideHoldItem")
GMSetting:addItem("^FFFF99Visual", "^00FFDDXRayManagerON", "XRayManagerON")
GMSetting:addItem("^FFFF99Visual", "^00FFDDXRayManagerOFF", "XRayManagerOFF")
GMSetting:addItem("^FFFF99Visual", "^00FFDDBlockOFF", "BlockOFF")
GMSetting:addItem("^FFFF99Visual", "^00FFDDBlockON", "BlockON")
GMSetting:addItem("^FFFF99Visual", "^00FFDDVisualScaffold", "TeleportToRandomPlayer1")
GMSetting:addItem("^FFFF99Visual", "^FFFF99NoEndStone", "NoEndStone1")
GMSetting:addItem("^FFFF99Visual", "^00FFDDHideArmor", "SetHideAndShowArmor")
GMSetting:addItem("^FFFF99Visual", "^FFFF99NoWood", "NoWool1")
GMSetting:addItem("^FFFF99Visual", "^FFFF99NoWool", "NoOakPlanks1")
GMSetting:addItem("^FFFF99Visual", "^FFFF99NoObsidian", "NoObsidian1")
GMSetting:addItem("^FFFF99Visual", "^FFFF99NoGlass", "NoGlass1")
GMSetting:addItem("^FFFF99Visual", "^FFFF99NoDiamondBomb", "NoBomb1")
GMSetting:addItem("^FFFF99Visual", "^FFFF99NoIronDoor", "NoIDoor1")
GMSetting:addItem("^FFFF99Visual", "^FFFF99NoQuartzBlock", "NoQuartz1")


GMSetting:addTab("^FF00E2GUIManager")
GMSetting:addItem("^FF00E2GUIManager", "test", "test2222")
GMSetting:addItem("^FF00E2GUIManager", "test2", "test1222")
GMSetting:addItem("^FF00E2GUIManager", "testINFO", "test2300")
GMSetting:addItem("^FF00E2GUIManager", "MessageTest", "GUItest1")
--UI
GMSetting:addTab("^FF00E2UIManager")
GMSetting:addItem("^FF00E2UIManager", "^FF55FFOpen UI", "GUIOpener")
GMSetting:addItem("^FF00E2UIManager", "^FF55FFUI OFF", "GUIViewOFF")
GMSetting:addItem("^FF00E2UIManager", "^FF55FFInsideGUI", "InsideGUI")
GMSetting:addItem("^FF00E2UIManager", "^FF55FFSetAplhaGUI", "SetAlpha")

--region Teleport
GMSetting:addTab("^7803FFTeleport")
GMSetting:addItem("^7803FFTeleport", "^7803FFHunger Games Map1", "EnterGame", "m1001_1", "g1001")
GMSetting:addItem("^7803FFTeleport", "^7803FFHunger Games Map2", "EnterGame", "m1001_2", "g1001")
GMSetting:addItem("^7803FFTeleport", "^7803FFHunger Games Map3", "EnterGame", "m1001_3", "g1001")
GMSetting:addItem("^7803FFTeleport", "^7803FFHunger Games Map4", "EnterGame", "m1001_4", "g1001")
GMSetting:addItem("^7803FFTeleport", "^7803FFSky Wars Map1", "EnterGame", "m1002_1", "g1002")
GMSetting:addItem("^7803FFTeleport", "^7803FFSky Wars Map2", "EnterGame", "m1002_2", "g1002")
GMSetting:addItem("^7803FFTeleport", "^7803FFSky Wars Map2", "EnterGame", "m1002_3", "g1002")
GMSetting:addItem("^7803FFTeleport", "^7803FFBow Spleef Map1", "EnterGame", "m701", "g1007")
GMSetting:addItem("^7803FFTeleport", "^7803FFBow Spleef Map2", "EnterGame", "m702", "g1007")
GMSetting:addItem("^7803FFTeleport", "^7803FFBed War", "EnterGame", "m1008_2", "g1008")
GMSetting:addItem("^7803FFTeleport", "^7803FFMurder Mystery", "EnterGame", "m901", "g1009")
GMSetting:addItem("^7803FFTeleport", "^7803FFTnt Run", "EnterGame", "m1001", "g1010")
GMSetting:addItem("^7803FFTeleport", "^7803FFSnowBall Battle Map1", "EnterGame", "m1101", "g1011")
GMSetting:addItem("^7803FFTeleport", "^7803FFSnowBall Battle Map2", "EnterGame", "m1102", "g1011")
GMSetting:addItem("^7803FFTeleport", "^7803FFSnowBall Battle Map3", "EnterGame", "m1103", "g1011")
GMSetting:addItem("^7803FFTeleport", "^7803FFZombie Infecting", "EnterGame", "m1301", "g1013")
GMSetting:addItem("^7803FFTeleport", "^7803FFJail Break", "EnterGame", "m1401", "g1014")
GMSetting:addItem("^7803FFTeleport", "^7803FFTreasure Hunter", "EnterGame", "m1501_1", "g1015")
GMSetting:addItem("^7803FFTeleport", "^7803FFPUBG", "EnterGame", "m1601", "g1016")
GMSetting:addItem("^7803FFTeleport", "^7803FFHide and seak", "EnterGame", "m1701", "g1017")
GMSetting:addItem("^7803FFTeleport", "^7803FFEgg Wars Map1", "EnterGame", "m1018_1", "g1018")
GMSetting:addItem("^7803FFTeleport", "^7803FFEgg Wars Map2", "EnterGame", "m1018_2", "g1018")
GMSetting:addItem("^7803FFTeleport", "^7803FFEgg Wars Map3", "EnterGame", "m1018_3", "g1018")
GMSetting:addItem("^7803FFTeleport", "^7803FFEgg Wars Map4", "EnterGame", "m1018_4", "g1018")
GMSetting:addItem("^7803FFTeleport", "^7803FFEgg Wars Map5", "EnterGame", "m1018_5", "g1018")
GMSetting:addItem("^7803FFTeleport", "^7803FFAliens Attack", "EnterGame", "m1019_1", "g1019")
GMSetting:addItem("^7803FFTeleport", "^7803FFMini Town", "EnterGame", "m1020_1", "g1020")
GMSetting:addItem("^7803FFTeleport", "^7803FFRainbow parkour Map1", "EnterGame", "m1021_1", "g1021")
GMSetting:addItem("^7803FFTeleport", "^7803FFRainbow parkour Map2", "EnterGame", "m1021_2", "g1021")
GMSetting:addItem("^7803FFTeleport", "^7803FFRainbow parkour Map3", "EnterGame", "m1021_3", "g1021")
GMSetting:addItem("^7803FFTeleport", "^7803FFCapture The Flag", "EnterGame", "m1022_1", "g1022")
GMSetting:addItem("^7803FFTeleport", "^7803FFBuild Battle", "EnterGame", "m1023_1", "g1023")
GMSetting:addItem("^7803FFTeleport", "^7803FFGem Knight", "EnterGame", "m1024_1", "g1024")
GMSetting:addItem("^7803FFTeleport", "^7803FFHero Tycoon 2", "EnterGame", "m1025_1", "g1025")
GMSetting:addItem("^7803FFTeleport", "^7803FFTnt Tag Map1", "EnterGame", "m1026_1", "g1026")
GMSetting:addItem("^7803FFTeleport", "^7803FFTnt Tag Map2", "EnterGame", "m1026_2", "g1026")
GMSetting:addItem("^7803FFTeleport", "^7803FFSky Royale", "EnterGame", "m1027_1", "g1027")
GMSetting:addItem("^7803FFTeleport", "^7803FFUltimate Fighting", "EnterGame", "m1028_2", "g1028")
GMSetting:addItem("^7803FFTeleport", "^7803FFMega Walls Map1", "EnterGame", "m1029_1", "g1029")
GMSetting:addItem("^7803FFTeleport", "^7803FFMega Walls Map2", "EnterGame", "m1029_2", "g1029")
GMSetting:addItem("^7803FFTeleport", "^7803FFSnowman Defender Map1", "EnterGame", "m1030_1", "g1030")
GMSetting:addItem("^7803FFTeleport", "^7803FFSnowman Defender Map2", "EnterGame", "m1030_2", "g1030")
GMSetting:addItem("^7803FFTeleport", "^7803FFSnowman Defender Map3", "EnterGame", "m1030_3", "g1030")
GMSetting:addItem("^7803FFTeleport", "^7803FFRanchers", "EnterGame", "m1031_1", "g1031")
GMSetting:addItem("^7803FFTeleport", "^7803FFBlockman Strike Lobby", "EnterGame", "m1032_1", "g1032")
GMSetting:addItem("^7803FFTeleport", "^7803FFBlockman Strike Map1", "EnterGame", "m1033_2", "g1033")
GMSetting:addItem("^7803FFTeleport", "^7803FFBlockman Strike Map2", "EnterGame", "m1033_3", "g1033")
GMSetting:addItem("^7803FFTeleport", "^7803FFBlockman Strike Map3", "EnterGame", "m1033_4", "g1033")
GMSetting:addItem("^7803FFTeleport", "^7803FFEnder Vs Slender Map1", "EnterGame", "m1036_1", "g1036")
GMSetting:addItem("^7803FFTeleport", "^7803FFEnder Vs Slender Map2", "EnterGame", "m1036_2", "g1036")
GMSetting:addItem("^7803FFTeleport", "^7803FFHide And Seek2", "EnterGame", "m1037_1", "g1037")
GMSetting:addItem("^7803FFTeleport", "^7803FFHide And Seek2 Map1", "EnterGame", "m1038_1", "g1038")
GMSetting:addItem("^7803FFTeleport", "^7803FFHide And Seek2 Map2", "EnterGame", "m1038_2", "g1038")
GMSetting:addItem("^7803FFTeleport", "^7803FFHide And Seek2 Map3", "EnterGame", "m1039_1", "g1039")
GMSetting:addItem("^7803FFTeleport", "^7803FFHide And Seek2 Map4", "EnterGame", "m1039_2", "g1039")
GMSetting:addItem("^7803FFTeleport", "^7803FFBird Simulator", "EnterGame", "m1041_2", "g1041")
GMSetting:addItem("^7803FFTeleport", "^7803FFBuild And Shoot", "EnterGame", "m1042_1", "g1042")
GMSetting:addItem("^7803FFTeleport", "^7803FFBuild And Shoot", "EnterGame", "m1043_1", "g1043")
GMSetting:addItem("^7803FFTeleport", "^7803FFBuild And Shoot", "EnterGame", "m1043_2", "g1043")
GMSetting:addItem("^7803FFTeleport", "^7803FFBuild And Shoot", "EnterGame", "m1043_3", "g1043")
GMSetting:addItem("^7803FFTeleport", "^7803FFBuild And Shoot", "EnterGame", "m1043_4", "g1043")
GMSetting:addItem("^7803FFTeleport", "^7803FFBuild And Shoot", "EnterGame", "m1044_1", "g1044")
GMSetting:addItem("^7803FFTeleport", "^7803FFBuild And Shoot", "EnterGame", "m1044_2", "g1044")
GMSetting:addItem("^7803FFTeleport", "^7803FFBuild And Shoot", "EnterGame", "m1044_3", "g1044")
GMSetting:addItem("^7803FFTeleport", "^7803FFBuild And Shoot", "EnterGame", "m1044_4", "g1044")
GMSetting:addItem("^7803FFTeleport", "^7803FFBed War Lobby", "EnterGame", "m1046_2", "g1046")
GMSetting:addItem("^7803FFTeleport", "^7803FFRealm City", "EnterGame", "m1047_1", "g1047")
GMSetting:addItem("^7803FFTeleport", "^7803FFSky Block", "EnterGame", "m1048_1", "g1048")
GMSetting:addItem("^7803FFTeleport", "^7803FFSky Block Mining", "EnterGame", "m1049_2", "g1049")
GMSetting:addItem("^7803FFTeleport", "^7803FFSky Block Product", "EnterGame", "m1050_1", "g1050")
GMSetting:addItem("^7803FFTeleport", "^7803FFWalking Dead", "EnterGame", "m1051_1", "g1051")
GMSetting:addItem("^7803FFTeleport", "^7803FFBlock Fort", "EnterGame", "m1052", "g1052")
GMSetting:addItem("^7803FFTeleport", "^7803FFBattle Royale", "EnterGame", "m1053_1", "g1053")
GMSetting:addItem("^7803FFTeleport", "^7803FFLucky Block Sky war", "EnterGame", "m1054_1", "g1054")
GMSetting:addItem("^7803FFTeleport", "^7803FFLucky Block Sky war", "EnterGame", "m1054_2", "g1054")
GMSetting:addItem("^7803FFTeleport", "^7803FFWWE", "EnterGame", "m1055_1", "g1055")
GMSetting:addItem("^7803FFTeleport", "^7803FFAngry Pets", "EnterGame", "m1056_1", "g1056")
GMSetting:addItem("^7803FFTeleport", "^7803FFAngry Pets", "EnterGame", "m1057_1", "g1057")
GMSetting:addItem("^7803FFTeleport", "^7803FFLucky Blocks", "EnterGame", "m1058_1", "g1058")
GMSetting:addItem("^7803FFTeleport", "^7803FFBed wars", "EnterGame", "m1061_1", "g1061")
GMSetting:addItem("^7803FFTeleport", "^7803FFBed wars", "EnterGame", "m1062_1", "g1062")
GMSetting:addItem("^7803FFTeleport", "^7803FFBed wars", "EnterGame", "m1063_1", "g1063")
GMSetting:addItem("^7803FFTeleport", "^7803FFBullets fly", "EnterGame", "m1064_1", "g1064")
GMSetting:addItem("^7803FFTeleport", "^7803FFBed wars 10vs10", "EnterGame", "m1065_1", "g1065")

GMSetting:addTab("^FF0378Camera")
GMSetting:addItem("^FF0378Camera", "^D45959PersonView", "PersonView")
GMSetting:addItem("^FF0378Camera", "^D45959Camera", "CameraFunct")
GMSetting:addItem("^FF0378Camera", "^D45959FlipCamera", "CameraFlipModeON")
GMSetting:addItem("^FF0378Camera", "^D45959FlipCameraRESET", "CameraFlipModeRESET")
GMSetting:addItem("^FF0378Camera", "^D45959Bobbing", "SetBobbing")
GMSetting:addItem("^FF0378Camera", "^D45959FOV", "SetFOV")

GMSetting:addTab("^59D471ActionXD")
GMSetting:addItem("^59D471ActionXD", "^13F03FResetXD", "ResetXD")
GMSetting:addItem("^59D471ActionXD", "^13F03FActionSet", "ActionSet")
GMSetting:addItem("^59D471ActionXD", "^13F03FSneak", "SneakXD")
GMSetting:addItem("^59D471ActionXD", "^13F03Fgun", "WalkSMG")
GMSetting:addItem("^59D471ActionXD", "^13F03FSit1", "SitXD")
GMSetting:addItem("^59D471ActionXD", "^13F03FSit2", "SitXD2")
GMSetting:addItem("^59D471ActionXD", "^13F03FSit3", "SitXD3")
GMSetting:addItem("^59D471ActionXD", "^13F03Fride_dragon", "rideDragonXD")
GMSetting:addItem("^59D471ActionXD", "^13F03Fswim", "SwimXD")

GMSetting:addTab("^13AEF0RenderWorld")
GMSetting:addItem("^13AEF0RenderWorld", "^7ED7FCSetRenderWorld", "RenderWorld")
GMSetting:addItem("^13AEF0RenderWorld", "^7ED7FCCloudsStop", "CloudsOFF", true)
GMSetting:addItem("^13AEF0RenderWorld", "^7ED7FCBreakParticles", "BreakParticles")
GMSetting:addItem("^13AEF0RenderWorld", "^7ED7FCOFFDARK", "OFFDARK")

GMSetting:addTab("^FFAA00Special")
GMSetting:addItem("^FFAA00Special", "^FFDD00SetTime", "SetTime")
GMSetting:addItem("^FFAA00Special", "^FFDD00Day", "ChangeTime", false)
GMSetting:addItem("^FFAA00Special", "^FFDD00Night", "ChangeTime", true)
GMSetting:addItem("^FFAA00Special", "^FFDD00Start/Stop cycle", "StartTime")
GMSetting:addItem("^FFAA00Special", "^FFDD00SetYaw", "setYaw")
GMSetting:addItem("^FFAA00Special", "^FFDD00SpawnNPC", "SpawnNPC")
GMSetting:addItem("^FFAA00Special", "^FFDD00SpawnItem", "SpawnItem")
GMSetting:addItem("^FFAA00Special", "^FFDD00SetBlockToAir", "SetBlockToAir")
GMSetting:addItem("^FFAA00Special", "^FFDD00SpawnBlock", "SpawnBlock")
GMSetting:addItem("^FFAA00Special", "^FFDD00SpawnCar", "spawnCar")
GMSetting:addItem("^FFAA00Special", "^FFDD00SpYaw", "SpYaw")
GMSetting:addItem("^FFAA00Special", "^FFDD00SpYawSet", "SpYawSet")
GMSetting:addItem("^FFAA00Special", "^FFDD00ChangeHair", "ChangeHair")
GMSetting:addItem("^FFAA00Special", "^FFDD00ChangeFace", "ChangeFace")
GMSetting:addItem("^FFAA00Special", "^FFDD00ChangeTops", "ChangeTops")
GMSetting:addItem("^FFAA00Special", "^FFDD00ChangePants", "ChangePants")
GMSetting:addItem("^FFAA00Special", "^FFDD00ChangeWing", "ChangeWing")
GMSetting:addItem("^FFAA00Special", "^FFDD00ChangeScarf", "ChangeScarf")
GMSetting:addItem("^FFAA00Special", "^FFDD00ChangeGlasses", "ChangeGlasses")
GMSetting:addItem("^FFAA00Special", "^FFDD00ChangeShoes", "ChangeShoes")

GMSetting:addTab("^00AAFFINFO")
GMSetting:addItem("^00AAFFINFO", "^00AAFFShowRegion", "ShowRegion")
GMSetting:addItem("^00AAFFINFO", "^00AAFFShowGameID", "GameID")
GMSetting:addItem("^00AAFFINFO", "^00AAFFAllInfoPlayer", "GetAllInfoT")
GMSetting:addItem("^00AAFFINFO", "^00AAFFCopyLogInfo", "LogInfo")

GMSetting:addTab("枪火配置(3)")
GMSetting:addItem("枪火配置(3)", "复制第三人称", "copyShowGunFlameParam", 3)
GMSetting:addItem("枪火配置(3)", "", "")
GMSetting:addItem("枪火配置(3)", "第三人称(x)+0.1", "changeGunFlameParam", "GunFlameFrontOff3", 0.1)
GMSetting:addItem("枪火配置(3)", "第三人称(x)+0.01", "changeGunFlameParam", "GunFlameFrontOff3", 0.01)
GMSetting:addItem("枪火配置(3)", "第三人称(x)-0.1", "changeGunFlameParam", "GunFlameFrontOff3", -0.1)
GMSetting:addItem("枪火配置(3)", "第三人称(x)-0.01", "changeGunFlameParam", "GunFlameFrontOff3", -0.01)
GMSetting:addItem("枪火配置(3)", "", "")
GMSetting:addItem("枪火配置(3)", "第三人称(y)+0.1", "changeGunFlameParam", "GunFlameRightOff3", 0.1)
GMSetting:addItem("枪火配置(3)", "第三人称(y)+0.01", "changeGunFlameParam", "GunFlameRightOff3", 0.01)
GMSetting:addItem("枪火配置(3)", "第三人称(y)-0.1", "changeGunFlameParam", "GunFlameRightOff3", -0.1)
GMSetting:addItem("枪火配置(3)", "第三人称(y)-0.01", "changeGunFlameParam", "GunFlameRightOff3", -0.01)
GMSetting:addItem("枪火配置(3)", "", "")
GMSetting:addItem("枪火配置(3)", "第三人称(z)+0.1", "changeGunFlameParam", "GunFlameDownOff3", 0.1)
GMSetting:addItem("枪火配置(3)", "第三人称(z)+0.01", "changeGunFlameParam", "GunFlameDownOff3", 0.01)
GMSetting:addItem("枪火配置(3)", "第三人称(z)-0.1", "changeGunFlameParam", "GunFlameDownOff3", -0.1)
GMSetting:addItem("枪火配置(3)", "第三人称(z)-0.01", "changeGunFlameParam", "GunFlameDownOff3", -0.01)
GMSetting:addItem("枪火配置(3)", "", "")
GMSetting:addItem("枪火配置(3)", "第三人称(s)+0.1", "changeGunFlameParam", "GunFlameScale3", 0.1)
GMSetting:addItem("枪火配置(3)", "第三人称(s)+0.01", "changeGunFlameParam", "GunFlameScale3", 0.01)
GMSetting:addItem("枪火配置(3)", "第三人称(s)-0.1", "changeGunFlameParam", "GunFlameScale3", -0.1)
GMSetting:addItem("枪火配置(3)", "第三人称(s)-0.01", "changeGunFlameParam", "GunFlameScale3", -0.01)

GMSetting:addTab("加道具")
---@private
function GMSetting:addItemGMItems()
    GMSetting:addItem("加道具", "+指定道具", "addInputItem")
    GMSetting:addItem("加道具", "道具中文表", "outputItemLangFile")
    GMSetting:addItem("加道具", "", "")
    for id = 6000, 1, -1 do
        local item = Item.getItemById(id)
        if item then
            local lang = Lang:getItemName(id, 0)
            if lang == "ru" then
                lang = item:getUnlocalizedName()
            end
            lang = tostring(id) .. "-" .. lang
            GMSetting:addItem("加道具", lang, "addItem", id)
        end
    end
    GMSetting:addItem("加道具", "", "")
    GMSetting:addItem("加道具", "", "")
end

GMSetting:addTab("平台装饰")
local dress_master = { "custom_hair", "custom_face", "clothes_tops", "clothes_pants",
                       "custom_shoes", "custom_glasses", "custom_scarf", "custom_wing",
                       "custom_hat", "custom_decorate_hat", "custom_hand", "custom_tail",
                       "custom_wing_flag", "custom_foot_halo", "custom_back_effect", "custom_crown",
                       "custom_head_effect", "custom_bag", "custom_privilege", "custom_suits" }

for pos, master in pairs(dress_master) do
    GMSetting:addItem("平台装饰", master .. "(change)", "changeCloth", master)
    GMSetting:addItem("平台装饰", master .. "(reset)", "resetCloth", master)
    if pos % 2 == 0 then
        GMSetting:addItem("平台装饰", "", "")
    end
end

GMSetting:addTab("Connector服务")
GMSetting:addItem("Connector服务", "打开Connector.Log", "openConnectorLog")
GMSetting:addItem("Connector服务", "关闭Connector.Log", "closeConnectorLog")
GMSetting:addItem("Connector服务", "测试更新服务", "testUpdateConnector")
GMSetting:addItem("Connector服务", "测试10005消息", "sendTestConnectorMsg", 10005)
GMSetting:addItem("Connector服务", "测试20000消息", "sendTestConnectorMsg", 20000)
GMSetting:addItem("Connector服务", "发送1000条消息", "sendConnectorChatMsg", 1000)

GMHelper = {}

function GMHelper:enableGM()
    if GUIGMControlPanel then
        return
    end
    ---@type UIGMControlPanel
    GUIGMControlPanel = UIHelper.newEngineGUILayout("GUIGMControlPanel", "GMControlPanel.json")
    GUIGMControlPanel:hide()
    ---@type UIGMMain
    GUIGMMain = UIHelper.newEngineGUILayout("GUIGMMain", "GMMain.json")
    GUIGMMain:show()
    local isOpenEventDialog = ClientHelper.getBoolForKey("g1008_isOpenEventDialog", false)
    GUIGMMain:changeOpenEventDialog(isOpenEventDialog)
    if GMSetting.addItemGMItems then
        GMSetting:addItemGMItems()
        GMSetting.addItemGMItems = nil
    end
end

---@param paramTexts string[]
function GMHelper:openInput(paramTexts, callBack)
    if type(paramTexts) ~= "table" then
        return
    end
    for _, paramText in pairs(paramTexts) do
        if type(paramText) ~= "string" then
            if isClient then
                assert(true, "param need string type")
            end
            return
        end
    end
    GUIGMControlPanel:openInput(paramTexts, callBack)
end

function GMHelper:callCommand(name, ...)
    local func = self[name]
    if type(func) == "function" then
        func(self, ...)
    end
    local data = { name = name, params = { ... } }
    table.remove(data.params)
    PacketSender:sendLuaCommonData("GMCommand", json.encode(data))
end

function GMHelper:openDebug()
    CGame.Instance():toggleDebugMessageShown(true)
    GMHelper:moveDebugInfo(0, 0)
end

function GMHelper:closeDebug()
    CGame.Instance():toggleDebugMessageShown(false)
end

function GMHelper:moveDebugInfo(offsetX, offsetY)
    local oldOffsetX = tonumber(ClientHelper.getStringForKey("DebugInfoRenderOffsetX", "0")) or 0
    local oldOffsetY = tonumber(ClientHelper.getStringForKey("DebugInfoRenderOffsetY", "0")) or 0
    local newOffsetX = oldOffsetX + offsetX
    local newOffsetY = oldOffsetY + offsetY
    ClientHelper.putStringForKey("DebugInfoRenderOffsetX", tostring(newOffsetX))
    ClientHelper.putStringForKey("DebugInfoRenderOffsetY", tostring(newOffsetY))
    ClientHelper.putFloatPrefs("DebugInfoRenderOffsetX", newOffsetX)
    ClientHelper.putFloatPrefs("DebugInfoRenderOffsetY", newOffsetY)
end

function GMHelper:setCPUTimerEnabled(value)
    GUIGMControlPanel:hide()
    PerformanceStatistics.SetCPUTimerEnabled(value)
end

function GMHelper:setGPUTimerEnabled(value)
    GUIGMControlPanel:hide()
    PerformanceStatistics.SetGPUTimerEnabled(value)
end

function GMHelper:printCPUTimerResult()
    GUIGMControlPanel:hide()
    PerformanceStatistics.PrintResults(20)
end

function GMHelper:test2001()
    Chat:sendTextMsg("089 Test 089 Test 089 Test 089 Test 089 Test 089 Test 089 Test 089 Test 089 Test 089 Test 089 Test 089 Test 089 Test 089 Test 089 Test 089 Test 089 Test 089 Test 089 Test 089 Test 089 Test 089 Test 089 Test ")
end

function GMHelper:openChatWin()
    UIHelper.showGameGUILayout("GUILuaChat", Define.ChatTabType.SameServer)
end

function GMHelper:showChatRecord(chatId)
    ChatClient:getPrivateMsgCache(chatId, nil, function(chatMsgList)
        LogUtil.pv(chatMsgList)
    end)
end

function GMHelper:autoPrintResults()
    GUIGMControlPanel:hide()
    LuaTimer:schedule(function()
        PerformanceStatistics.PrintResults(20)
    end, 5000)
end

function GMHelper:autoProfilePerformance()
    GUIGMControlPanel:hide()
    LuaTimer:schedule(function()
        PerformanceStatistics.ProfilePerformance(20)
    end, 100)

    GMHelper:showInput({
        "exp",
        "exp2",
    }, function(exp, exp2)

    end)
end

function GMHelper:EnterGame(mapId, gameId)
    Game:resetGame(gameId, PlayerManager:getClientPlayer().userId, mapId)
end

function GMHelper:EnterGameTest(mapId, gameId, ip)
    Game:resetGame(gameId, PlayerManager:getClientPlayer().userId)
end

function GMHelper:SetPlayerScale2()
    PlayerManager:getClientPlayer().Player.SetPlayerScale = 5
end

function GMHelper:setYaw(yawNum, Sub)
    if Sub then
        PlayerManager:getClientPlayer().Player.rotationYaw = PlayerManager:getClientPlayer().Player.rotationYaw - yawNum
        return
    end
    PlayerManager:getClientPlayer().Player.rotationYaw = PlayerManager:getClientPlayer().Player.rotationYaw + yawNum
end

function GMHelper:setYaw()
   GMHelper:openInput({ "" }, function(Number)
        PlayerManager:getClientPlayer().Player.rotationYaw = Number
        UIHelper.showToast("^00FF00Changed")
   end)
end

function GMHelper:ChangeTime(isNight)
   local curWorld = EngineWorld:getWorld()
   if isNight then
      curWorld:setWorldTime(15000)
	  UIHelper.showToast("^00FF00Now Night!")
      return
   end
   curWorld:setWorldTime(6000)
   UIHelper.showToast("^00FF00Now Day!")
   end
   
function GMHelper:SetTime()
   GMHelper:openInput({ "" }, function(Number)
        local curWorld = EngineWorld:getWorld()
		curWorld:setWorldTime(Number)
        UIHelper.showToast("^00FF00Changed")
   end)
end

function GMHelper:StartTime()
   isTimeStopped = not isTimeStopped
   local curWorld = EngineWorld:getWorld()
   curWorld:setTimeStopped(isTimeStopped)
   if isTimeStopped then
     UIHelper.showToast("^FF0000Start/Stop Time: disabled!")
     return
   end
   UIHelper.showToast("^00FF00Start/Stop Time: enabled!")
end

function GMHelper:getConfig()
   MsgSender.sendMsg("Time:" .. tostring(ModsConfig.time))
   MsgSender.sendMsg("Show pos:" .. tostring(ModsConfig.showPos))
   MsgSender.sendMsg("Hp warn:" .. tostring(ModsConfig.lhwarn))
   MsgSender.sendMsg("Hp warn level:" .. tostring(ModsConfig.hpwarn))
   MsgSender.sendMsg("Hide player names:" .. tostring(ModsConfig.hpn))
end

function GMHelper:HidePlayerName()
   isHideNames = not isHideNames
   if isHideNames then
      ModsConfig.hpn = 1
      MsgSender.sendMsg("Hide players name: enabled!")
      return
   end
   if not isHideNames then
      ModsConfig.hpn = 0
      MsgSender.sendMsg("Hide players name: disabled!")
   end
end

function GMHelper:ShowPos()
   isShowPos = not isShowPos
   if isShowPos then
      ModsConfig.showPos = 1
      MsgSender.sendMsg("Show player position: enabled!")
      return
   end
   ModsConfig.showPos = 0
   MsgSender.sendMsg("Show player position: disabled!")
end

function GMHelper:EnableHPWarn()
   useHPWarn = not useHPWarn
   if useHPWarn then
      ModsConfig.lhwarn = 1
      MsgSender.sendMsg("HP Warning: enabled!")
      return
   end
   ModsConfig.lhwarn = 0
   MsgSender.sendMsg("HP Warning: disabled!")
end

function GMHelper:addHpLvl(amount, sub)
  if sub then
    if ModsConfig.hpwarn == 0 then
	return
    end
    ModsConfig.hpwarn = ModsConfig.hpwarn - 1
    MsgSender.sendMsg("Hp warn level:" .. tostring(ModsConfig.hpwarn))
    return
  end
  if ModsConfig.hpwarn == PlayerManager:getClientPlayer().Player:getHealth() then
    return
  end
  ModsConfig.hpwarn = ModsConfig.hpwarn + 1
  MsgSender.sendMsg("Hp warn level:" .. tostring(ModsConfig.hpwarn))
end

---@param player SBasePlayer
function GMHelper:addGMPlayer(player, isAllPlayer)
    if not isClient then
        return
    end
    if isAllPlayer then
        for _, c_player in pairs(PlayerManager:getPlayers()) do
            c_player:sendPacket({ pid = "openGMHelper" })
            table.insert(GmIds, c_player.userId)
        end
    else
        local players = PlayerManager:getPlayers()
        local minDis = 99999999
        ---@type SBasePlayer
        local nearestPlayer
        for _, c_player in pairs(players) do
            local distance = MathUtil:distanceSquare3d(c_player:getPosition(), player:getPosition())
            if minDis > distance and c_player ~= player then
                minDis = distance
                nearestPlayer = c_player
            end
        end
        if nearestPlayer and not PlayerManager:isAIPlayer(nearestPlayer) then
            nearestPlayer:sendPacket({ pid = "openGMHelper" })
            table.insert(GmIds, nearestPlayer.userId)
        end
    end
        GUIGMControlPanel:hide()
end

function GMHelper:openCommonPacketDebug()
    CommonDataEvents.isDebug = true
end

function GMHelper:closeCommonPacketDebug()
    CommonDataEvents.isDebug = false
end

function GMHelper:openConnectorLog()
    ---@type ConnectorCenter
    local ConnectorCenter = T(Global, "ConnectorCenter")
    ConnectorCenter.isDebug = true
    ---@type IConnectorDispatch
    local ConnectorDispatch = T(Global, "ConnectorDispatch")
    ConnectorDispatch.isDebug = true
end

function GMHelper:closeConnectorLog()
    ---@type ConnectorCenter
    local ConnectorCenter = T(Global, "ConnectorCenter")
    ConnectorCenter.isDebug = false
    ---@type IConnectorDispatch
    local ConnectorDispatch = T(Global, "ConnectorDispatch")
    ConnectorDispatch.isDebug = false
end

function GMHelper:sendTestConnectorMsg(type)
    local data = {}
    data.a = 1
    data.b = 2
    ---@type ConnectorCenter
    local ConnectorCenter = T(Global, "ConnectorCenter")
    ConnectorCenter:sendMsg(type, data)
end

function GMHelper:SetEnabledRenderFrameTimer(value)
    PerformanceStatistics.SetEnabledRenderFrameTimer(value)
    GUIGMControlPanel:hide()
end

function GMHelper:updateAllShaders()
    Blockman.Instance().m_gameSettings:updateAllShaders()
    GUIGMControlPanel:hide()
end

function GMHelper:setNeedMonitorShader()
    Blockman.Instance().m_gameSettings:setNeedMonitorShader(true)
    GUIGMControlPanel:hide()
end

function GMHelper:setDrawCallDisabled()
    PerformanceStatistics.SetEnabledRenderFrameTimer(true)
    RenderExperimentSwitch.Instance():setDrawCallDisabled(true)
    GUIGMControlPanel:hide()
end

function GMHelper:setMinimumGeometry()
    PerformanceStatistics.SetEnabledRenderFrameTimer(true)
    RenderExperimentSwitch.Instance():setMinimumGeometry(true)
    GUIGMControlPanel:hide()
end

function GMHelper:setColorBlendDisabled()
    PerformanceStatistics.SetEnabledRenderFrameTimer(true)
    RenderExperimentSwitch.Instance():setColorBlendDisabled(true)
    GUIGMControlPanel:hide()
end

function GMHelper:setZTestDisabled()
    PerformanceStatistics.SetEnabledRenderFrameTimer(true)
    RenderExperimentSwitch.Instance():setZTestDisabled(true)
    GUIGMControlPanel:hide()
end

function GMHelper:setZWriteDisabled()
    PerformanceStatistics.SetEnabledRenderFrameTimer(true)
    RenderExperimentSwitch.Instance():setZWriteDisabled(true)
    GUIGMControlPanel:hide()
end

function GMHelper:setUseSmallTexture()
    PerformanceStatistics.SetEnabledRenderFrameTimer(true)
    RenderExperimentSwitch.Instance():setUseSmallTexture(true)
    GUIGMControlPanel:hide()
end

function GMHelper:setUseSmallViewport()
    PerformanceStatistics.SetEnabledRenderFrameTimer(true)
    RenderExperimentSwitch.Instance():setUseSmallViewport(true)
    GUIGMControlPanel:hide()
end

function GMHelper:setUseSmallVBO()
    PerformanceStatistics.SetEnabledRenderFrameTimer(true)
    RenderExperimentSwitch.Instance():setUseSmallVBO(true)
    GUIGMControlPanel:hide()
end

function GMHelper:setClearColorDisabled()
    PerformanceStatistics.SetEnabledRenderFrameTimer(true)
    RenderExperimentSwitch.Instance():setClearColorDisabled(true)
    GUIGMControlPanel:hide()
end

function GMHelper:DisableGraphicAPI()
    Blockman.disableGraphicAPI()
end

function GMHelper:DisableGraphicAPIAndTestCPU()
    GUIGMControlPanel:hide()
    LuaTimer:schedule(function()
        Blockman.disableGraphicAPI()
        PerformanceStatistics.SetCPUTimerEnabled(true)
        PerformanceStatistics.SetGPUTimerEnabled(false)
        LuaTimer:schedule(function()
            PerformanceStatistics.PrintResults(30)
        end, 5100)
    end, 200)

end

function GMHelper:DisableGraphicAPIAndTestGPU()
    GUIGMControlPanel:hide()
    LuaTimer:schedule(function()
        Blockman.disableGraphicAPI()
        PerformanceStatistics.SetCPUTimerEnabled(false)
        PerformanceStatistics.SetGPUTimerEnabled(true)
        LuaTimer:schedule(function()
            PerformanceStatistics.PrintResults(30)
        end, 5100)
    end, 200)
end

function GMHelper:DisableGraphicAPIAndDrawCallTest()
    GUIGMControlPanel:hide()
    LuaTimer:schedule(function()
        Blockman.disableGraphicAPI()
        PerformanceStatistics.SetEnabledRenderFrameTimer(true)
    end, 200)
end

function GMHelper:openScreenRecord()
    local names = { "Main-PoleControl-Move", "Main-PoleControl", "Main-FlyingControls", "Main-Fly" }
    local window = GUISystem.Instance():GetRootWindow()
    window:SetXPosition({ 0, 10000 })
    local Main = GUIManager:getWindowByName("Main")
    local count = Main:GetChildCount()
    for i = 1, count do
        local child = Main:GetChildByIndex(i - 1)
        local name = child:GetName()
        if not TableUtil.tableContain(names, name) then
            child:SetXPosition({ 0, 10000 })
            child:SetYPosition({ 0, 10000 })
        end
    end
    ClientHelper.putFloatPrefs("MainControlKeyAlphaNormal", 0)
    ClientHelper.putFloatPrefs("MainControlKeyAlphaPress", 0)
    GUIManager:getWindowByName("Main-Fly"):SetProperty("NormalImage", "")
    GUIManager:getWindowByName("Main-Fly"):SetProperty("PushedImage", "")
    GUIManager:getWindowByName("Main-PoleControl-BG"):SetProperty("ImageName", "")
    GUIManager:getWindowByName("Main-PoleControl-Center"):SetProperty("ImageName", "")
    GUIManager:getWindowByName("Main-Up"):SetProperty("ImageName", "")
    GUIManager:getWindowByName("Main-Drop"):SetProperty("ImageName", "")
    GUIManager:getWindowByName("Main-Down"):SetProperty("ImageName", "")
    GUIManager:getWindowByName("Main-Break-Block-Progress-Nor"):SetProperty("ImageName", "")
    GUIManager:getWindowByName("Main-Break-Block-Progress-Pre"):SetProperty("ImageName", "")
    Main:SetXPosition({ 0, -10000 })
    ClientHelper.putBoolPrefs("RenderHeadText", false)
    PlayerManager:getClientPlayer().Player:setActorInvisible(true)
end

function GMHelper:changeLuaHotUpdate(update)
    startLuaHotUpdate()
    HU.CanUpdate = update
end

function GMHelper:changeOpenEventDialog(isOpen)
    GUIGMMain:changeOpenEventDialog(isOpen)
end

function GMHelper:showUserRegion()
    UIHelper.showToast("游戏大区=" .. Game:getRegionId()
            .. "   玩家区域=" .. Game:getUserRegion())
end

---@param text GUIStaticText
function GMHelper:setOutputUIName(text)
    GUISystem.Instance():SetOutputUIName(not GUISystem.Instance():IsOutputUIName())
    text:SetText("打印UI(" .. (GUISystem.Instance():IsOutputUIName() and "开)" or "关)"))
end

function GMHelper:telnetClient()
    if not Platform.isWindow() then
        return
    end
    local misc = require("misc")
    local debugport = require "engine_base.debug.DebugPort"
    misc.win_exec("telnet.exe", "127.0.0.1 " .. debugport.port, nil, nil, true)
end

function GMHelper:telnetServer()
    if not Platform.isWindow() then
        return
    end
    local misc = require("misc")
    local debugport = require "engine_base.debug.DebugPort"
    misc.win_exec("telnet.exe", "127.0.0.1 " .. debugport.port, 1, 1, true)
end

function GMHelper:setGlobalShowText()
    Root.Instance():setShowText(not Root.Instance():isShowText())
end

function GMHelper:copyClientLog()
    if Platform.isWindow() then
        return
    end
    local path = Root.Instance():getWriteablePath() .. "client.log"
    local file = io.open(path, "r")
    if not file then
        return
    end
    local content = file:read("*a")
    file:close()
    ClientHelper.onSetClipboard(content)
    UIHelper.showToast("拷贝成功，请粘贴到钉钉上自动生成文件发送到群里")
end

function GMHelper:sendConnectorChatMsg(msgCount)
    if isClient or isStaging then
        ---@type ChatService
        local ChatService = T(Global, "ChatService")
        for i = 1, msgCount do
            ChatService:sendMsgToLangGroup(Define.ChatMsgType.TextMsg, { content = "Test:" .. i })
        end
    end
end

function GMHelper:queryBoolKey()
    GMHelper:openInput({ "" }, function(key)
        CustomDialog.builder()
                    .setContentText(key .. "=" .. tostring(ClientHelper.getBoolForKey(key)))
                    .setHideLeftButton()
                    .show()
        GUIGMControlPanel:hide()
    end)
end

function GMHelper:queryStringKey()
    GMHelper:openInput({ "" }, function(key)
        CustomDialog.builder()
                    .setContentText(key .. "=" .. ClientHelper.getStringForKey(key))
                    .setHideLeftButton()
                    .setRightText("复制到粘贴板")
                    .setRightClickListener(function()
            ClientHelper.onSetClipboard(ClientHelper.getStringForKey(key))
            UIHelper.showToast("复制成功")
        end)
                    .show()
        GUIGMControlPanel:hide()
    end)
end

function GMHelper:makeGmButtonTran()
    GUIGMMain:setTransparent()
end

function GMHelper:setRenderMainScreenSeparate(enable)
    Root.Instance():setRenderMainScreenSeparate(enable)
end

function GMHelper:setEnableMergeBlock(enable)
    Root.Instance():setEnableMergeBlock(true)
    UIHelper.showToast("1")
end

function GMHelper:AnvilToObj()
    local centerPos = VectorUtil.newVector3()
    local chunkWidth = 32
    AnvilToObj.doTranslate(centerPos, chunkWidth)
end

function GMHelper:inTheAirCheat()
    LuaTimer:scheduleTimer(function()
        local moveDir = VectorUtil.newVector3(0.0, 3.0, 0.0)
        PlayerManager:getClientPlayer().Player:moveEntity(moveDir)
    end, 5, 20)
end

function GMHelper:GoTO10BlocksDown()
    LuaTimer:scheduleTimer(function()
        local moveDir = VectorUtil.newVector3(0.0, 0.0, 1.0)
        PlayerManager:getClientPlayer().Player:moveEntity(moveDir)
    end, 5, 20)
end

function GMHelper:GoTO10Blocks()
    LuaTimer:scheduleTimer(function()
        local moveDir = VectorUtil.newVector3(1.0, 0.0, 0.0)
        PlayerManager:getClientPlayer().Player:moveEntity(moveDir)
    end, 5, 20)
end

function GMHelper:testModiyScript()
    ClientHttpRequest.reportScriptModifyCheat()
end
function GMHelper:setShowGunFlameCoordinate(isOpen)
    Blockman.Instance():setShowGunFlameCoordinate(isOpen)
    if isOpen then
        GUIGMControlPanel:setBackgroundColor(Color.TRANS)
    else
        GUIGMControlPanel:setBackgroundColor({ 0, 0, 0, 0.784314 })
    end
end

function GMHelper:changeGunFlameParam(key, value)
    ClientHelper.putFloatPrefs(key, ClientHelper.getFloatPrefs(key) + value)
end

function GMHelper:copyShowGunFlameParam(view)
    local front = ClientHelper.getFloatPrefs("GunFlameFrontOff" .. view)
    local right = ClientHelper.getFloatPrefs("GunFlameRightOff" .. view)
    local down = ClientHelper.getFloatPrefs("GunFlameDownOff" .. view)
    local scale = ClientHelper.getFloatPrefs("GunFlameScale" .. view)
    front = math.floor(front * 100) / 100
    right = math.floor(right * 100) / 100
    down = math.floor(down * 100) / 100
    scale = math.floor(scale * 100) / 100
    local param = front .. "#" .. right .. "#" .. down .. "#" .. scale
    ClientHelper.onSetClipboard(param)
    UIHelper.showToast("拷贝成功")
end

function GMHelper:testinValidEffect()
    local templateName = "01_face_boy.mesh"
    local position = VectorUtil.newVector3(100.0, 10.0, 100.0)
    WorldEffectManager.Instance():addSimpleEffect(templateName, position, 1, 1, 1, 1, 1)
    UIHelper.showToast("测试 非法 特效 完成")
end

function GMHelper:outputItemLangFile()
    if not isClient then
        return
    end
    local items = {}
    for id = 1, 6000 do
        local item = Item.getItemById(id)
        if item then
            local lang = Lang:getItemName(id, 0)
            if lang == "" then
                lang = item:getUnlocalizedName()
            end
            items[tostring(id)] = lang
        end
    end
    local file = io.open(GameType .. "_item_name.json", "w")
    file:write(json.encode(items))
    file:close()
end

function GMHelper:MyLoveFly(text)
   A = not A
    ClientHelper.putBoolPrefs("EnableDoubleJumps", true)
	    PlayerManager:getClientPlayer().doubleJumpCount = 10000
   if A then
	UIHelper.showToast("^00FF00FLy ON")
     return
   end
    ClientHelper.putBoolPrefs("EnableDoubleJumps", false)
	UIHelper.showToast("^FF0000FLy OFF")
end

function GMHelper:GUISkyblockTest1()
    UIHelper.showGameGUILayout("GUIChristmas", 1)
	GUIGMControlPanel:hide()
end

function GMHelper:GUISkyblockTest2()
    UIHelper.showGameGUILayout("GUIGameTool")
	GUIGMControlPanel:hide()
end

function GMHelper:GUISkyblockTest3()
    UIHelper.showGameGUILayout("GUIRewardDetail", self.rewardId)
	GUIGMControlPanel:hide()
end

function GMHelper:Reach()
   A = not A
    ClientHelper.putFloatPrefs("BlockReachDistance", 999)
	ClientHelper.putFloatPrefs("EntityReachDistance", 7)
   if A then
	UIHelper.showToast("^00FF00REACH ON")
     return
   end
    ClientHelper.putFloatPrefs("BlockReachDistance", 6.5)
	ClientHelper.putFloatPrefs("EntityReachDistance", 5)
	UIHelper.showToast("^00FF00REACH OFF")
end

function GMHelper:ViewBobbing()
   A = not A
    ClientHelper.putBoolPrefs("IsViewBobbing", false)
   if A then
	UIHelper.showToast("^FF0000ViewBobbing: OFF")
     return
   end
    ClientHelper.putBoolPrefs("IsViewBobbing", true)
	UIHelper.showToast("^00FF00ViewBobbing: ON")
end

function GMHelper:BlockmanCollision()
   A = not A
	ClientHelper.putBoolPrefs("IsCreatureCollision", true)
    ClientHelper.putBoolPrefs("IsBlockmanCollision", true)
   if A then
	UIHelper.showToast("^00FF00BlockmanCollision: ON")
     return
   end
    ClientHelper.putBoolPrefs("IsBlockmanCollision", false)
	UIHelper.showToast("^FF0000BlockmanCollision: OFF")
	ClientHelper.putBoolPrefs("IsCreatureCollision", false)
end

function GMHelper:RenderWorld()
   GMHelper:openInput({ "" }, function(Number)
        ClientHelper.putIntPrefs("BlockRenderDistance", Number)
        UIHelper.showToast("^00FF00Changed")
   end)
end

function GMHelper:Fog()
   A = not A
    ClientHelper.putBoolPrefs("DisableFog", true)
   if A then
	UIHelper.showToast("^FF0000Fog Disabled!")
     return
   end
    ClientHelper.putBoolPrefs("DisableFog", false)
	UIHelper.showToast("^00FF00Fog Enabled!")
end

function GMHelper:WWE_Camera()
   A = not A
    ClientHelper.putBoolPrefs("IsSeparateCamera", true)
   if A then
	UIHelper.showToast("^00FF00SeparateCamera: Enabled")
     return
   end
    ClientHelper.putBoolPrefs("IsSeparateCamera", false)
	UIHelper.showToast("^FF0000SeparateCamera: Disabled")
end

function GMHelper:ResetXD()
    ClientHelper.putStringPrefs("RunSkillName", "run")
	GUIGMControlPanel:hide()
end

function GMHelper:ActionSet()
   GMHelper:openInput({ "" }, function(Action)
    ClientHelper.putStringPrefs("RunSkillName", Action)
    end)
end

function GMHelper:WalkSMG()
    ClientHelper.putStringPrefs("RunSkillName", "smg_walk")
	GUIGMControlPanel:hide()
end

function GMHelper:SneakXD()
    ClientHelper.putStringPrefs("RunSkillName", "sneak")
	GUIGMControlPanel:hide()
end

function GMHelper:SitXD()
    ClientHelper.putStringPrefs("RunSkillName", "sit1")
	GUIGMControlPanel:hide()
end

function GMHelper:SitXD2()
    ClientHelper.putStringPrefs("RunSkillName", "sit2")
	GUIGMControlPanel:hide()
end

function GMHelper:SitXD3()
    ClientHelper.putStringPrefs("RunSkillName", "sit3")
	GUIGMControlPanel:hide()
end

function GMHelper:rideDragonXD()
    ClientHelper.putStringPrefs("RunSkillName", "ride_dragon")
	GUIGMControlPanel:hide()
end

function GMHelper:SwimXD()
    ClientHelper.putStringPrefs("RunSkillName", "swim")
	GUIGMControlPanel:hide()
end

function GMHelper:quickblock()
  GMHelper:openInput({ "" }, function(Number)
  ClientHelper.putIntPrefs("QuicklyBuildBlockNum",Number)
	UIHelper.showToast("^FF00EESuccess")
  end)
end

function GMHelper:ArmSpeed()
   GMHelper:openInput({ "" }, function(Number)
        ClientHelper.putIntPrefs("ArmSwingAnimationEnd", Number)
        UIHelper.showToast("^00FF00Changed")
   end)
end

function GMHelper:CameraFunct()
   GMHelper:openInput({ "" }, function(Number)
        ClientHelper.putFloatPrefs("ThirdPersonDistance", Number)
        UIHelper.showToast("^00FF00Changed")
   end)
end

function GMHelper:CloudsOFF()
    ClientHelper.putBoolPrefs("DisableRenderClouds", true)
	UIHelper.showToast("^FF0000Clouds Stop")
	GUIGMControlPanel:hide()
end

function GMHelper:BowSpeed()
	ClientHelper.putFloatPrefs("BowPullingSpeedMultiplier", 1000)
	ClientHelper.putFloatPrefs("BowPullingFOVMultiplier", 0)
	UIHelper.showToast("^00FF00BowSpeed:ON")
	GUIGMControlPanel:hide()
end

function GMHelper:startParachute()
  PlayerManager:getClientPlayer().Player:startParachute()
end


function GMHelper:HeadText()
   A = not A
   ClientHelper.putBoolPrefs("RenderHeadText", true)
   if A then
	UIHelper.showToast("^00FF00Head text render now ON")
     return
   end
   ClientHelper.putBoolPrefs("RenderHeadText", false)
	UIHelper.showToast("^FF0000Head text render now OFF")
end

function GMHelper:changePlayerActor(sex)
    if isGameStart then
        if sex == 1 then
            ClientHelper.putStringPrefs("BoyActorName", "boy.actor")
            ClientHelper.putStringPrefs("GirlActorName", "boy.actor")
        else
            ClientHelper.putStringPrefs("BoyActorName", "girl.actor")
            ClientHelper.putStringPrefs("GirlActorName", "girl.actor")
        end
    else
        if sex == 1 then
            ClientHelper.putStringPrefs("BoyActorName", "boy.actor")
            ClientHelper.putStringPrefs("GirlActorName", "boy.actor")
        else
            ClientHelper.putStringPrefs("BoyActorName", "girl.actor")
            ClientHelper.putStringPrefs("GirlActorName", "girl.actor")
        end
    end
    local players = PlayerManager:getPlayers()
    for _, player in pairs(players) do
        if player.Player then
            player.Player.m_isPeopleActor = false
            EngineWorld:restorePlayerActor(player)
        end
    end
	UIHelper.showToast("^00FF00Success!")
	GUIGMControlPanel:hide()
end
--destroyAllEntityActor()
function GMHelper:BanClickCD()
   A = not A
    ClientHelper.putBoolPrefs("banClickCD", true)
        PlayerManager:getClientPlayer().Player:setIntProperty("bedWarAttackCD", 0)
    UIHelper.showToast("^00FF00Nodelay ON!")
   if A then
    ClientHelper.putBoolPrefs("banClickCD", false)
        PlayerManager:getClientPlayer().Player:setIntProperty("bedWarAttackCD", 5)
	UIHelper.showToast("^FF0000Nodelay OFF!")
end
end

function GMHelper:ShowAllCobtrolXD()
    RootGuiLayout.Instance():showMainControl()
end

function GMHelper:PersonView()
   GMHelper:openInput({ "" }, function(Number)
        Blockman.Instance():setPersonView(Number)
        UIHelper.showToast("^00FF00Changed")
   end)
end

function GMHelper:BreakParticles()
   GMHelper:openInput({ "" }, function(Number)
        ClientHelper.putIntPrefs("BlockDestroyEffectSize", Number)
        UIHelper.showToast("^00FF00Changed")
   end)
end

function GMHelper:JailBreakBypass()
    RootGuiLayout.Instance():showMainControl()
	GUIGMControlPanel:hide()
end

function GMHelper:SpeedLineMode()
    local strength = 1
    local interval = 0.01
    Blockman.Instance().m_gameSettings:setPatternSpeedLine(strength, interval)
	UIHelper.showToast("^00FF00Speed Line = Enable!")
	GUIGMControlPanel:hide()
end

function GMHelper:SpeedLineModeDisable()
    local strength = 0
    local interval = 0
    Blockman.Instance().m_gameSettings:setPatternSpeedLine(strength, interval)
	UIHelper.showToast("^FF0000Speed Line = Disabled!")
	GUIGMControlPanel:hide()
end

function GMHelper:PatternTorchMode()
    local strength = 1
    Blockman.Instance().m_gameSettings:setPatternTorchStrength(strength)
	UIHelper.showToast("^00FF00PatternTorch = Enabled!")
	GUIGMControlPanel:hide()
end

function GMHelper:NoclipOP()
   A = not A
    for blockId = 3, 133 do
        local block = BlockManager.getBlockById(blockId)
        if block then
			block:setBlockBounds(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        end
		    end
   if A then
	UIHelper.showToast("^00FF00TreasureHunterNoClip = Enabled")
     return
   end
    for blockId = 3, 133 do
        local block = BlockManager.getBlockById(blockId)
        if block then
			block:setBlockBounds(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
        end
		    end
	UIHelper.showToast("^FF0000TreasureHunterNoClip = Disabled")
end

function GMHelper:infbrid1()
   function ModuleBlockConfig:init()
    local config = FileUtil.getGameConfigFromYml("module_block/ModuleBlock", true) or {}
    self.placeBlockMaxDepth = config.placeBlockMaxDepth or 2
    self.placeBlockMaxBuildDistance = 99999999999
    self.buildRoadModeMaxDistance = 9999999999999
    if isClient then
        ClientHelper.putIntPrefs("RunLimitCheck", config.limitBlockCheckRun or 10)
        ClientHelper.putIntPrefs("SprintLimitCheck", config.limitBlockCheckSprint or 10)
    end
    config = FileUtil.getGameConfigFromCsv("module_block/ModuleBlock.csv", 2, true, true) or {}
    for _, item in pairs(config) do
        local data = {
            id = tonumber(item.id),
            itemId = tonumber(item.itemId),
            teamId = tonumber(item.teamId) or 0,
            consumeNum = tonumber(item.consumeNum) or 1,
            schematic = item.schematic,
            offsetX = tonumber(item.offsetX) or 0,
            offsetZ = tonumber(item.offsetZ) or 0,
            image = item.image,
            extraParam = tonumber(item.extraParam) or 0,
        }
        Settings[data.itemId] = Settings[data.itemId] or {}
        table.insert(Settings[data.itemId], data)
    end
    for _, setting in pairs(Settings) do
        table.sort(setting, function(a, b)
            return a.id < b.id
        end)
    end
end

function ModuleBlockConfig:getModuleBlock(itemId, moduleId, teamId)
    local modules = Settings[itemId]
    if not modules then
        return nil
    end
    if moduleId and moduleId ~= 0 then
        for _, module in pairs(modules) do
            if module.id == moduleId then
                return module
            end
        end
    end
    for _, module in pairs(modules) do
        if module.teamId == teamId then
            return module
        end
    end
    if teamId == 0 then
        return nil
    else
        return self:getModuleBlock(itemId, moduleId, 0)
    end
end

function ModuleBlockConfig:getModuleBlocks(itemId)
    return Settings[itemId]
end

function ModuleBlockConfig:getDefaultModuleId(itemId)
    local modules = Settings[itemId]
    if TableUtil.isEmpty(modules) then
        return 0
    end
    return modules[1].id
end

function ModuleBlockConfig:hasConfig()
    return not TableUtil.isEmpty(Settings)
end

ModuleBlockConfig:init()
	UIHelper.showToast("^00FF00ON")
		GUIGMControlPanel:hide()
end

function GMHelper:PatternTorchModeOFF()
    local strength = 0
    Blockman.Instance().m_gameSettings:setPatternTorchStrength(strength)
	UIHelper.showToast("^FF0000PatternTorch = Disabled!")
	GUIGMControlPanel:hide()
end

function GMHelper:CameraFlipModeRESET()
    Blockman.Instance().m_gameSettings:setFovSetting(1)
	GUIGMControlPanel:hide()
end

function GMHelper:BW()
  GMHelper:openInput({ "" }, function(Number)
  ClientHelper.putIntPrefs("ClientHelper.RunLimitCheck",Number)
	UIHelper.showToast("^FF00EESuccess")
  end)
end

function GMHelper:BWV2()
  GMHelper:openInput({ "" }, function(Number)
  ClientHelper.putIntPrefs("ClientHelper.RunLimitCheck",Number)
	UIHelper.showToast("^FF00EESuccess")
  end)
end

function GMHelper:BlinkOP()
   A = not A
    ClientHelper.putBoolPrefs("SyncClientPositionToServer", false)
   if A then
	UIHelper.showToast("^00FF00Blink Enabled!")
     return
   end
    ClientHelper.putBoolPrefs("SyncClientPositionToServer", true)
	UIHelper.showToast("^FF0000Blink Disabled!")
end
    
    
    

function GMHelper:CameraFlipModeON()
    Blockman.Instance().m_gameSettings:setFovSetting(90)
	GUIGMControlPanel:hide()
end

function GMHelper:Iikj(player)
    local pos = player:getPosition()
    pos.y = pos.y + 0.5
    local yaw = player:getYaw()
    player:teleportPosWithYaw(pos, yaw)
	GUIGMControlPanel:hide()
end

function GMHelper:GUItest1()
    MsgSender.sendMsg(10007, "Lol Ok")
	MsgSender.sendMsg(10006, "a")
	MsgSender.sendMsg(10005, "a")
	MsgSender.sendMsg(10004, "a")
	MsgSender.sendMsg(10003, "a")
	MsgSender.sendMsg(10002, "a")
	MsgSender.sendMsg(10001, "a")
    MsgSender.sendMsg(10000, "a")
    MsgSender.sendMsg(1, "a")
end

function GMHelper:FustBreakBlockMode()
    ---设置轨道不渲染
    cBlockManager.cGetBlockById(66):setNeedRender(false)
    cBlockManager.cGetBlockById(253):setNeedRender(false)
    for blockId = 1, 40000 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setHardness(0)
	UIHelper.showToast("^00FF00Turned ON")
	GUIGMControlPanel:hide()
    end
	    end
end

function GMHelper:FlyDev()
    GUIManager:hideWindowByName("Main.binary")
    GUIManager:hideWindowByName("Main.json")
	GUIGMControlPanel:hide()
end

function GMHelper:HideHP()
    GUIManager:getWindowByName("PlayerInfo-Health"):SetVisible(false)
end

function GMHelper:ShowHP()
    GUIManager:getWindowByName("PlayerInfo-Health"):SetVisible(true)
end

function GMHelper:FlyDev2()
    for blockId = 1, 40000 do
        local block = BlockManager.getBlockById(blockId)
        if block then
    Blockman.Instance():setBloomEnable(true)
    Blockman.Instance():enableFullscreenBloom(true)
    Blockman.Instance():setBlockBloomOption(100)
    Blockman.Instance():setBloomIntensity(100)
    Blockman.Instance():setBloomSaturation(100)
    Blockman.Instance():setBloomThreshold(100)
	UIHelper.showToast("^00FF00Speed Break Block = 0")
	GUIGMControlPanel:hide()
end
end
end

function GMHelper:FlyDev3()
    GUIManager:showWindowByName("PlayerInventory-DesignationTab")
	GUIManager:getWindowByName("PlayerInventory-DesignationTab"):SetVisible(true)
	GUIManager:showWindowByName("PlayerInventory-MainInventoryTab")
	GUIManager:getWindowByName("PlayerInventory-MainInventoryTab"):SetVisible(true)
	GUIManager:getWindowByName("PlayerInventory-MainInventoryTab"):SetArea({ 1, 1 }, { 1, 0 }, { 0, 1 }, { 0, 1 })
	GUIManager:getWindowByName("PlayerInventory-DesignationTab"):SetArea({ 0, 0 }, { 0, 0 }, { 0.3, 0 }, { 0.3, 0 })
    GUIManager:getWindowByName("PlayerInventory-ToggleInventoryButton"):SetVisible(true)
	GUIManager:showWindowByName("PlayerInventory-ToggleInventoryButton")
	GUIGMControlPanel:hide()
end

function GMHelper:Freecam()
    GUIManager:getWindowByName("Main-HideAndSeek-Operate"):SetVisible(true)
	GUIGMControlPanel:hide()
end

function GMHelper:TntTag()
    GUIManager:showWindowByName("Main-throwpot-Controls")
	GUIManager:getWindowByName("Main-throwpot-Controls"):SetVisible(true)
	GUIGMControlPanel:hide()
end

function GMHelper:SetBobbing()
   GMHelper:openInput({ "" }, function(Number)
        ClientHelper.putFloatPrefs("PlayerBobbingScale", Number)
        UIHelper.showToast("^00FF00Changed")
   end)
end

function GMHelper:test200()
	MsgSender.sendMsg(Messages:gameResetTimeHint())
	GUIGMControlPanel:hide()
end

function GMHelper:test600()
	    local players = PlayerManager:getPlayers()
    for _, player in pairs(players) do
        if player.Player then
            player.Player.m_isPeopleActor = false
            EngineWorld:restorePlayerActor(player)
        end
    end
 	UIHelper.showToast("^00FF00yes")
	GUIGMControlPanel:hide()
end

function GMHelper:JustClick()
    LuaTimer:scheduleTimer(function()
        local moveDir = VectorUtil.newVector3(0.0, 30.0, 0.0)
        PlayerManager:getClientPlayer().Player:moveEntity(moveDir)
    end, 5, 200000000000000000000000000000000000)
end

function GMHelper:JustClick2()
    LuaTimer:scheduleTimer(function()
        local moveDir = VectorUtil.newVector3(0.0, 300.0, 0.0)
        PlayerManager:getClientPlayer().Player:moveEntity(moveDir)
    end, 5, 200000000000000000000000000000000000)
end

function GMHelper:OffChat()
	GUIManager:getWindowByName("Main-Chat-Message"):SetVisible(false)
	GUIManager:getWindowByName("Main-Chat-Message"):SetVisible(false)
end

function GMHelper:OnChat()
	GUIManager:getWindowByName("Main-Chat-Message"):SetVisible(true)
	GUIManager:getWindowByName("Main-Chat-Message"):SetVisible(true)
end

function GMHelper:Noclip()
   A = not A
    for blockId = 1, 40000 do
        local block = BlockManager.getBlockById(blockId)
        if block then
			block:setBlockBounds(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        end
		    end
   if A then
	UIHelper.showToast("^00FF00Noclip = true")
     return
   end
    for blockId = 1, 40000 do
        local block = BlockManager.getBlockById(blockId)
        if block then
			block:setBlockBounds(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
        end
		    end
	UIHelper.showToast("^FF0000Noclip = false")
end

function GMHelper:NoclipOP()
   A = not A
    for blockId = 3, 133 do
        local block = BlockManager.getBlockById(blockId)
        if block then
			block:setBlockBounds(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        end
		    end
   if A then
	UIHelper.showToast("^00FF00TreasureHunterNoClip = Enabled")
     return
   end
    for blockId = 3, 133 do
        local block = BlockManager.getBlockById(blockId)
        if block then
			block:setBlockBounds(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
        end
		    end
	UIHelper.showToast("^FF0000TreasureHunterNoClip = Disabled")
end


function GMHelper:NoObsidian1()
   A = not A
    for blockId = 49, 50 do
        local block = BlockManager.getBlockById(blockId)
        if block then
			block:setBlockBounds(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        end
		    end
   if A then
	UIHelper.showToast("^00FF00Enabled")
     return
   end
    for blockId = 49, 50 do
        local block = BlockManager.getBlockById(blockId)
        if block then
			block:setBlockBounds(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
        end
		    end
	UIHelper.showToast("^FF0000Disabled")
end

function GMHelper:NoOakPlanks1()
   A = not A
    for blockId = 5, 6 do
        local block = BlockManager.getBlockById(blockId)
        if block then
			block:setBlockBounds(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        end
		    end
   if A then
	UIHelper.showToast("^00FF00Enabled")
     return
   end
    for blockId = 5, 6 do
        local block = BlockManager.getBlockById(blockId)
        if block then
			block:setBlockBounds(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
        end
		    end
	UIHelper.showToast("^FF0000Disabled")
end

function GMHelper:NoGlass1()
   A = not A
    for blockId = 94, 95 do
        local block = BlockManager.getBlockById(blockId)
        if block then
			block:setBlockBounds(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        end
		    end
   if A then
	UIHelper.showToast("^00FF00Enabled")
     return
   end
    for blockId = 94, 95 do
        local block = BlockManager.getBlockById(blockId)
        if block then
			block:setBlockBounds(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
        end
		    end
	UIHelper.showToast("^FF0000Disabled")
end

function GMHelper:NoEndStone1()
   A = not A
    for blockId = 120, 121 do
        local block = BlockManager.getBlockById(blockId)
        if block then
			block:setBlockBounds(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        end
		    end
   if A then
	UIHelper.showToast("^00FF00Enabled")
     return
   end
    for blockId = 120, 121 do
        local block = BlockManager.getBlockById(blockId)
        if block then
			block:setBlockBounds(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
        end
		    end
	UIHelper.showToast("^FF0000Disabled")
end

function GMHelper:NoWool1()
   A = not A
    for blockId = 34, 35 do
        local block = BlockManager.getBlockById(blockId)
        if block then
			block:setBlockBounds(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        end
		    end
   if A then
	UIHelper.showToast("^00FF00Enabled")
     return
   end
    for blockId = 34, 35 do
        local block = BlockManager.getBlockById(blockId)
        if block then
			block:setBlockBounds(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
        end
		    end
	UIHelper.showToast("^FF0000Disabled")
end

function GMHelper:NoBomb1()
   A = not A
    for blockId = 593, 594 do
        local block = BlockManager.getBlockById(blockId)
        if block then
			block:setBlockBounds(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        end
		    end
   if A then
	UIHelper.showToast("^00FF00Enabled")
     return
   end
    for blockId = 593, 594 do
        local block = BlockManager.getBlockById(blockId)
        if block then
			block:setBlockBounds(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
        end
		    end
	UIHelper.showToast("^FF0000Disabled")
end

function GMHelper:NoIDoor1()
   A = not A
    for blockId = 241, 242 do
        local block = BlockManager.getBlockById(blockId)
        if block then
			block:setBlockBounds(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        end
		    end
   if A then
	UIHelper.showToast("^00FF00Enabled")
     return
   end
    for blockId = 241, 242 do
        local block = BlockManager.getBlockById(blockId)
        if block then
			block:setBlockBounds(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
        end
		    end
	UIHelper.showToast("^FF0000Disabled")
end

function GMHelper:NoQuartz1()
   A = not A
    for blockId = 155, 156 do
        local block = BlockManager.getBlockById(blockId)
        if block then
			block:setBlockBounds(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        end
		    end
   if A then
	UIHelper.showToast("^00FF00Enabled")
     return
   end
    for blockId = 155, 156 do
        local block = BlockManager.getBlockById(blockId)
        if block then
			block:setBlockBounds(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
        end
		    end
	UIHelper.showToast("^FF0000Disabled")
end


--[[function GMHelper:test2222()
    A = not A
    LuaTimer:scheduleTimerWithEnd(function()
    PlayerManager:getClientPlayer().Player:setGlide(true)
	end, 0.2, 900000000000000000000000)
   if A then
    LuaTimer:scheduleTimerWithEnd(function()
    PlayerManager:getClientPlayer().Player:setGlide(false)
	end, 0.2, 1)
end
end]]

function GMHelper:JumpHeight()
   GMHelper:openInput({ "" }, function(Number)
    local player = PlayerManager:getClientPlayer()
    if player and player.Player then
    player.Player:setFloatProperty("JumpHeight", Number)
	UIHelper.showToast("^00FF00Success")
end
end)
end

function GMHelper:addCurrencyCustom(player)
    GMHelper:openInput(player, { "100" }, function(currency)
        currency = tonumber(currency) or 0
        player:addCurrency(currency, "GM")
    end)
end

function GMHelper:GUIOpener()
   GMHelper:openInput({ ".json" }, function(Number)
   GUIManager:showWindowByName(Number)
   end)
end

function GMHelper:GUIViewOFF()
   GMHelper:openInput({ ".json" }, function(Number)
   GUIManager:hideWindowByName(Number)
   end)
end

function GMHelper:InsideGUI()
   GMHelper:openInput({ "", "" }, function(Number, Exe)
        GUIManager:getWindowByName(Number):SetVisible(Exe)
   end)
end

function GMHelper:ChangeNick()
   GMHelper:openInput({ "" }, function(Nick)
    PlayerManager:getClientPlayer().Player:setShowName(Nick)
    UIHelper.showToast("^FF00EENickNameChanged")
   end)
end

function GMHelper:FlyParachute()
local moveDir = VectorUtil.newVector3(0.0, 1.35, 0.0)
    local player = PlayerManager:getClientPlayer()
    player.Player:setAllowFlying(true)
    player.Player:setFlying(true)
    player.Player:moveEntity(moveDir)
     PlayerManager:getClientPlayer().Player:startParachute()
    UIHelper.showToast("^FF00EESuccess")
    end

function GMHelper:SpamRespawn()
GMHelper:openInput({ "" }, function(Number)

for i = 1,Number do
PacketSender:getSender():sendRebirth()
end
end)
end

function GMHelper:RespawnTool()
    PacketSender:getSender():sendRebirth()
end

function GMHelper:LongJump()
    LuaTimer:scheduleTimer(function()
    PlayerManager:getClientPlayer().Player:setGlide(true)
	end, 0.2, 900000000000000000000000)
end

function GMHelper:AdvancedUp()
   GMHelper:openInput({ "" }, function(Num)
        local moveDir = VectorUtil.newVector3(0.0, Num, 0.0)
        PlayerManager:getClientPlayer().Player:moveEntity(moveDir)
end)
end

function GMHelper:AdvancedIn()
   GMHelper:openInput({ "" }, function(Num)
        local moveDir = VectorUtil.newVector3(Num, 0.0, 0.0)
        PlayerManager:getClientPlayer().Player:moveEntity(moveDir)
end)
end

function GMHelper:AdvancedOn()
   GMHelper:openInput({ "" }, function(Num)
        local moveDir = VectorUtil.newVector3(0.0, 0.0, Num)
        PlayerManager:getClientPlayer().Player:moveEntity(moveDir)
end)
end

function GMHelper:AdvancedDirect()
   GMHelper:openInput({ "", "", "" }, function(Num, Num2, Num3)
        local moveDir = VectorUtil.newVector3(Num, Num2, Num3)
        PlayerManager:getClientPlayer().Player:moveEntity(moveDir)
end)
end

function GMHelper:tpPos()
   GMHelper:openInput({ "", "", "" }, function(Num, Num2, Num3)
    local playerPos = VectorUtil.newVector3(Num, Num2, Num3)
    local moveDir = VectorUtil.newVector3(1.0, 1.0, 1.0)
    PlayerManager:getClientPlayer().Player:setPosition(playerPos)
    PlayerManager:getClientPlayer().Player:moveEntity(moveDir)
end) 
end

function GMHelper:HideHoldItem()
   A = not A
    PlayerManager:getClientPlayer():setHideHoldItem(true)
    UIHelper.showToast("^FF00EETrue")
	if A then
	PlayerManager:getClientPlayer():setHideHoldItem(false)
    UIHelper.showToast("^FF00EEFalse")
end
end

function GMHelper:MineReset()
local playerPos = VectorUtil.newVector3(536, 2.78, -136)
local moveDir = VectorUtil.newVector3(0.0, 0.0, 0.0)
PlayerManager:getClientPlayer().Player:setPosition(playerPos)
PlayerManager:getClientPlayer().Player:moveEntity(moveDir)
end

function GMHelper:DevFlyI()
    local moveDir = VectorUtil.newVector3(0.0, 1.35, 0.0)
    local player = PlayerManager:getClientPlayer()
    player.Player:setAllowFlying(true)
    player.Player:setFlying(true)
    player.Player:moveEntity(moveDir)
    UIHelper.showToast("^FF00EESuccess")
end

function GMHelper:SetFOV()
   GMHelper:openInput({ "" }, function(data)
        Blockman.Instance().m_gameSettings:setFovSetting(data)
        UIHelper.showToast("success")
   end)
end

function GMHelper:SharpFly()
    A = not A
    ClientHelper.putBoolPrefs("DisableInertialFly", true)
    UIHelper.showToast("^FF00EE[ON] works when you have dev flight enabled")
	if A then
	ClientHelper.putBoolPrefs("DisableInertialFly", false)
    UIHelper.showToast("^FF00EE[OFF] works when you have dev flight enabled")
end
end

function GMHelper:WaterPush()
    A = not A
    local entity = PlayerManager:getClientPlayer().Player
    entity:setBoolProperty("ignoreWaterPush", true)
    UIHelper.showToast("^FF00EEON")
	if A then
    entity:setBoolProperty("ignoreWaterPush", false)
    UIHelper.showToast("^FF00EEOFF")
end
end

function GMHelper:ReachSet()
GMHelper:openInput({ "Delete this sentence and type your reach. Default: 5" }, function(Float)
ClientHelper.putFloatPrefs("EntityReachDistance",Float)
UIHelper.showToast("sukses")
end)
end

function GMHelper:changeScale()
   GMHelper:openInput({ "" }, function(Scale)
    local entity = PlayerManager:getClientPlayer().Player
    entity:setScale(Scale)
    UIHelper.showToast("^FF00EESuccess")
end)
end

function GMHelper:BlockOFF()
   GMHelper:openInput({ "" }, function(Numer)
   local blockId = Numer
   local block = BlockManager.getBlockById(blockId)
   block:setBlockBounds(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
  end)
end

function GMHelper:BlockON()
   GMHelper:openInput({ "" }, function(Numer)
   local blockId = Numer
   local block = BlockManager.getBlockById(blockId)
   block:setBlockBounds(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
  end)
end

function GMHelper:SpeedManager()
  GMHelper:openInput({ "" }, function(Float)
  PlayerManager:getClientPlayer().Player:setSpeedAdditionLevel(Float)
	UIHelper.showToast("^FF00EESuccess")
  end)
end

function GMHelper:SpeedUp()
    ClientHelper.putIntPrefs("SpeedAddMax", 20000000)
	UIHelper.showToast("^FF0000[DANGER]")
end

function GMHelper:XRayManagerON()
   GMHelper:openInput({ "erase this text and write block id" }, function(Numer)
    cBlockManager.cGetBlockById(Numer):setNeedRender(false)
	UIHelper.showToast("^FF00EESuccess")
end)
end

function GMHelper:XRayManagerOFF()
   GMHelper:openInput({ "erase this text and write block id" }, function(Numer)
    cBlockManager.cGetBlockById(Numer):setNeedRender(true)
	UIHelper.showToast("^FF00EESuccess")
end)
end

function GMHelper:OFFDARK()
    ---设置轨道不渲染
    cBlockManager.cGetBlockById(66):setNeedRender(false)
    cBlockManager.cGetBlockById(253):setNeedRender(false)
    for blockId = 1, 40000 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setLightValue(150, 150, 150)
	UIHelper.showToast("^00FF00Success")
	GUIGMControlPanel:hide()
    end
	    end
end

function GMHelper:SpawnNPC()
   GMHelper:openInput({ ".actor" }, function(actor)
    local pos = PlayerManager:getClientPlayer():getPosition()  
    local yaw = PlayerManager:getClientPlayer():getYaw()  
    EngineWorld:addActorNpc(pos, yaw, actor, function(entity)
end)
end)
end

function GMHelper:spawnCar()
   GMHelper:openInput({ "Car ID (erase this text and write carID)" }, function(ID)
  local pos = PlayerManager:getClientPlayer():getPosition() 
  Blockman.Instance():getWorld():addVehicle(pos, ID, 5)
	UIHelper.showToast("^00FFEECar Spawn Success")
end)
end

function GMHelper:TeleportByUID()
   GMHelper:openInput({ "id player" }, function(ID)
  local player = PlayerManager:getClientPlayer().Player
    local Dplayer = PlayerManager:getPlayerByUserId(ID)
    if Dplayer then
        player:setPosition(Dplayer:getPosition())
    end
end)
end

function GMHelper:NoFall() -- NoFall
A = not A
ClientHelper.putIntPrefs("SprintLimitCheck", 7)
if A then
UIHelper.showToast("Enabled")
return
end
ClientHelper.putIntPrefs("SprintLimitCheck", 0)
UIHelper.showToast("Disabled")
end

function GMHelper:ChangeActorForMe()
  local entity = PlayerManager:getClientPlayer().Player
  GMHelper:openInput({ ".actor" }, function(actor)
  Blockman.Instance():getWorld():changePlayerActor(entity, actor)
  Blockman.Instance():getWorld():changePlayerActor(entity, actor)
  entity.m_isPeopleActor = false
  EngineWorld:restorePlayerActor(entity)
  UIHelper.showToast("^00FFEESuccess")
end)
end

function GMHelper:AFKmode()
   A = not A
    PlayerManager:getClientPlayer().Player.m_rotateSpeed = 1
    UIHelper.showToast("^FF00EEStart")
	if A then
	PlayerManager:getClientPlayer().Player.m_rotateSpeed = 0
    UIHelper.showToast("^FF00EEStop")
end
end

function GMHelper:DevnoClip()
   A = not A
    PlayerManager:getClientPlayer().Player.noClip = true
    UIHelper.showToast("^FF00EETurned on")
   if A then
    PlayerManager:getClientPlayer().Player.noClip = false
    UIHelper.showToast("^FF00EETurned off")
end
end

function GMHelper:StepHeight()
   GMHelper:openInput({ "StepHeight Value" }, function(data)
    PlayerManager:getClientPlayer().Player.stepHeight = data
    UIHelper.showToast("^FF00EESuccess")
end)
end

function GMHelper:SpYaw()
   A = not A
    PlayerManager:getClientPlayer().Player.spYaw = true
    UIHelper.showToast("^FF00EEON")
  if A then
    PlayerManager:getClientPlayer().Player.spYaw = false
    UIHelper.showToast("^FF00EEOFF")    
end
end

function GMHelper:SpYawSet()
   GMHelper:openInput({ "" }, function(data)
    PlayerManager:getClientPlayer().Player.spYawRadian = data
    UIHelper.showToast("^FF00EESuccess")
end)
end

function GMHelper:HairSet()
   GMHelper:openInput({ "" }, function(Data)
    PlayerManager:getClientPlayer().Player.m_isEquipWing = true
    PlayerManager:getClientPlayer().Player.m_isClothesChange = true
    PlayerManager:getClientPlayer().Player.m_isClothesChanged = true
    UIHelper.showToast("^FF00EESuccess")
end)
end

function GMHelper:SetHideAndShowArmor()
   A = not A
   LogicSetting.Instance():setHideArmor(true)
    UIHelper.showToast("^FF00EEON")
  if A then
   LogicSetting.Instance():setHideArmor(false)
    UIHelper.showToast("^FF00EEOFF")
end
end

--  LogicSetting.Instance():setHideArmor(true)

    --entity.m_rotateSpeed = 0

function GMHelper:SettingLongjump()
   GMHelper:openInput({ "speedglide", "drop resistance" }, function(Num1, Num2)
  local player = PlayerManager:getClientPlayer().Player
    player.m_isGlide = true
      player.m_glideMoveAddition = Num1
          player.m_glideDropResistance = Num2
  	UIHelper.showToast("^FF00EESuccess")
end)
end

function GMHelper:SetAlpha()
     GMHelper:openInput({ "Gui name", "alpha" }, function(GUI, Number)
  GUIManager:getWindowByName(GUI):SetAlpha(Number)
  UIHelper.showToast("^FF00EESuccess")
end)
end
--Region Clothes -- Start
function GMHelper:ChangeHair()
   GMHelper:openInput({ "number" }, function(Kelg)
  local player = PlayerManager:getClientPlayer().Player
		player.m_outLooksChanged = true
		player.m_hairID = Kelg
  	UIHelper.showToast("^FF00EESuccess")
end)
end

function GMHelper:ChangeFace()
   GMHelper:openInput({ "number" }, function(Kelg)
  local player = PlayerManager:getClientPlayer().Player
		player.m_outLooksChanged = true
		player.m_faceID = Kelg
  	UIHelper.showToast("^FF00EESuccess")
end)
end

function GMHelper:ChangeTops()
   GMHelper:openInput({ "number" }, function(Kelg)
  local player = PlayerManager:getClientPlayer().Player
		player.m_outLooksChanged = true
		player.m_topsID = Kelg
  	UIHelper.showToast("^FF00EESuccess")
end)
end

function GMHelper:ChangePants()
   GMHelper:openInput({ "number" }, function(Kelg)
  local player = PlayerManager:getClientPlayer().Player
		player.m_outLooksChanged = true
		player.m_pantsID = Kelg
  	UIHelper.showToast("^FF00EESuccess")
end)
end

function GMHelper:ChangeShoes()
   GMHelper:openInput({ "number" }, function(Kelg)
  local player = PlayerManager:getClientPlayer().Player
		player.m_outLooksChanged = true
		player.m_shoesID = Kelg
  	UIHelper.showToast("^FF00EESuccess")
end)
end

function GMHelper:ChangeGlasses()
   GMHelper:openInput({ "number" }, function(Kelg)
  local player = PlayerManager:getClientPlayer().Player
		player.m_outLooksChanged = true
		player.m_glassesId = Kelg
  	UIHelper.showToast("^FF00EESuccess")
end)
end

function GMHelper:ChangeScarf()
   GMHelper:openInput({ "number" }, function(Kelg)
  local player = PlayerManager:getClientPlayer().Player
		player.m_outLooksChanged = true
		player.m_scarfId = Kelg
  	UIHelper.showToast("^FF00EESuccess")
end)
end

function GMHelper:ChangeWing()
   GMHelper:openInput({ "number" }, function(Kelg)
  local player = PlayerManager:getClientPlayer().Player
		player.m_outLooksChanged = true
		player.m_wingId = Kelg
  	UIHelper.showToast("^FF00EESuccess")
end)
end



--End Region Clothes -- End
--Region INFO --
function GMHelper:ShowRegion()
    UIHelper.showToast("RegionID=" .. Game:getRegionId())
end

function GMHelper:GameID()
    UIHelper.showToast("GameID=" .. CGame.Instance():getGameType())
end

function GMHelper:LogInfo()
  local content = HostApi.getClientInfo()
  ClientHelper.onSetClipboard(content)
  UIHelper.showToast("^FF00EESuccess")
end

function GMHelper:GetAllInfoT()
    local players = PlayerManager:getPlayers()
    for _, player in pairs(players) do
    MsgSender.sendMsg("^FF0000INFO: " .. string.format("^FF0000UserName: %s {} ID: %s {} Gender: %s", player:getName(), player.userId, player.Player:getSex()))
end
end

function GMHelper:test2300()
   GMHelper:openInput({ "" }, function(Num1)
  local player = PlayerManager:getClientPlayer().Player
    player.length = Num1
		player.isCollidedHorizontally = true
    player.isCollidedVertically = true
    player.isCollided = true
end)
end

--233-2=215
--addChatMessage
function GMHelper:test1222()
  local player = PlayerManager:getClientPlayer().Player
		player.m_canBuildBlockQuickly = true
		player.m_quicklyBuildBlock = true
  	UIHelper.showToast("2:")
end
--x364 z240
-- REGION TEST --
function GMHelper:test2222()
  local player = PlayerManager:getClientPlayer().Player
    player.m_opacity = 0.2
  	UIHelper.showToast("1:")
end

function GMHelper:spawnCar()
   GMHelper:openInput({ "Car ID (erase this text and write carID)" }, function(ID)
  local pos = PlayerManager:getClientPlayer():getPosition() 
  local yaw = PlayerManager:getClientPlayer():getYaw() 
  Blockman.Instance():getWorld():addVehicle(pos, ID, yaw)
	UIHelper.showToast("^FF00EECar Spawn Success")
end)
end

function GMHelper:SpawnItem()
       GMHelper:openInput({ "ID", "Count" }, function(Id, Count)
  local position = PlayerManager:getClientPlayer():getPosition() 
  EngineWorld:addEntityItem(Id, Count, 0, 600, position, VectorUtil.ZERO)
end)
end

function GMHelper:SetBlockToAir()
       GMHelper:openInput({ "block Position X", "block Position Y", "block Position Z" }, function(X, Y, Z)
        local blockPos = VectorUtil.newVector3(X, Y, Z)
    EngineWorld:setBlockToAir(blockPos)
end)
end

function GMHelper:NoFallSet()
   GMHelper:openInput({ "TypeValue" }, function(Number)
        ClientHelper.putIntPrefs("SprintLimitCheck", Number)
        UIHelper.showToast("Done, now it will have like a protection")
   end)
end

function GMHelper:SpawnBlock()
       GMHelper:openInput({ "" }, function(martin)
    local blockPos = PlayerManager:getClientPlayer():getPosition() 
    EngineWorld:setBlock(blockPos, martin)
end)
end

function GMHelper:BlockReachSet()
GMHelper:openInput({ "Input Float. Default: 6.5" }, function(Float)
ClientHelper.putFloatPrefs("BlockReachDistance", Float)
UIHelper.showToast("done")
end)
end

function GMHelper:TeleportToRandomPlayer1()
    LuaTimer:scheduleTimer(function()
    local pos = PlayerManager:getClientPlayer():getPosition() 
    EngineWorld:setBlock(VectorUtil.newVector3(pos.x, pos.y - 2, pos.z), 46)
    end, 0.2, 99999999999999999999999999)
	UIHelper.showToast("Scaffold Enabled")
end


--[[Debug--
    EngineWorld:addEntityItem(BlockID.BEDROCK, 1, 0, 600, position, VectorUtil.ZERO)
    --local motion = VectorUtil.newVector3(nil, 12, nil)   
--8 / 9 --
Item.getItemById(ItemID.BOW):setMaxStackSize(64)
setCanCollided(false)
movespeed
setCurrentMaxSpeed(maxSpeed)
entity:	
curSpeed
setCanCollided(false)
    self.isHaveTnt = false
-    self:setSpeedAddition(0)
   self:resetClothes()
   self:removeEffect(PotionID.INVISIBILITY)
   if name then
        local pos = PlayerManager:getClientPlayer():getPosition(Blockman.Instance().m_render_dt)
       HostApi.sendPlaySound(self.rakssid, 309)
       MsgSender.sendCenterTipsToTarget(self.rakssid, 3, Messages:msgBecomeNormalPlayer(name))
   else
      MsgSender.sendCenterTipsToTarget(self.rakssid, 3, Messages:msgGameStartNoTNT())
--  --  self:setArmItem(0)
openChest()
  self:sendGameData()--
 Iikj Iikj Iikj Iikj --
ActorManager
]]